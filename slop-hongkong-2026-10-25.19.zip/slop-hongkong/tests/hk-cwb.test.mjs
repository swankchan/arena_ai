import assert from 'node:assert/strict';
import test from 'node:test';
import * as HK from '../js/hk/config.js';
import { CWB } from '../js/hk/cwb-geodata.js';
import { hk80GridToWgs84, hk80ToWorld, boundsFromGltf, isBuildingGltf } from '../js/hk/hk80.js';
import { parseCwbModelCap, selectCwbModels, matchCwbBuildingModels } from '../js/hk/cwb-model-plan.js';
import { trimPolyline } from '../js/hk/markings.js';
import { pointInFlatRing, resolveCircleAgainstFootprint, filterFootprintClearanceLanes } from '../js/hk/cwb-collision.js';
import { causewayBayBuildingColliders } from '../js/hk/cwb-buildings.js';

test('CWB pack is bounded, sourced, and includes the three landmark areas', () => {
  assert.ok(CWB.roads.length > 100);
  assert.ok(CWB.buildings.length > 500);
  assert.match(CWB.source.roads, /Lands Department/);
  assert.match(CWB.source.roads, /OpenStreetMap/);
  assert.match(CWB.source.buildings, /BaseHeight/);
  const names = CWB.buildings.map((building) => building.name);
  assert.ok(names.includes('Hysan Place'));
  assert.ok(names.includes('Times Square Tower One'));
  assert.ok(names.includes('Times Square Tower Two'));
  assert.ok(names.includes('Windsor House'));
  for (const road of CWB.roads) {
    for (let i = 0; i + 1 < road.pts.length; i += 2) {
      assert.ok(road.pts[i] >= CWB.bounds.minX - 0.11 && road.pts[i] <= CWB.bounds.maxX + 0.11, `${road.id} x clip`);
      assert.ok(road.pts[i + 1] >= CWB.bounds.minZ - 0.11 && road.pts[i + 1] <= CWB.bounds.maxZ + 0.11, `${road.id} z clip`);
    }
  }
});

test('CWB real buildings survive the full-graph road migration without seed duplicates', () => {
  assert.ok(HK.ROADS.length > 16000 && HK.ROADS.every((road) => road.source === 'landsd-osm-graph'));
  assert.ok(HK.TRAFFIC_ROADS.some((road) => road.source === 'landsd-osm' && road.en === 'Yee Wo Street'));
  assert.ok(HK.BUILDINGS.every((building) => !HK.inCausewayBayReplacement(building.x, building.z)));
  assert.ok(!HK.LANDMARKS.some((landmark) => landmark.id === 'times-square'));
  assert.ok(HK.ROADS.some((road) => road.en === 'Connaught Road Central'), 'full network includes Central');
  assert.ok(HK.TRAM.every((point) => point.x <= CWB.bounds.minX + 1e-6), 'incorrect seed tram rails do not cross the pilot');
});

test('real building parts have finite footprints and separate base/top heights', () => {
  for (const building of CWB.buildings) {
    assert.ok(building.ring.length >= 6 && building.ring.length % 2 === 0, building.id);
    assert.ok(building.h >= 2.5 && building.h <= 500, building.id);
    assert.ok(Number.isFinite(building.base), building.id);
    assert.ok(building.ring.every(Number.isFinite), building.id);
  }
  const hysan = CWB.buildings.find((building) => building.name === 'Hysan Place');
  assert.ok(hysan.base > 30, 'tower starts above its podium, not at ground');
  assert.ok(hysan.base + hysan.h > 190);
  const times = CWB.buildings.find((building) => building.name === 'Times Square Tower One');
  assert.ok(times.base > 60 && times.h > 120);
});

test('lane layout fits each carriageway and centres one-way lanes', () => {
  for (const road of HK.ROADS) {
    for (const dir of road.oneway ? [1] : [1, -1]) {
      const count = HK.laneCountFor(road, dir);
      const width = HK.laneWidthFor(road, dir);
      const available = road.oneway ? road.w : road.w / 2;
      assert.ok(width > 0 && count * width <= available + 1e-8, `${road.id || road.en} exceeds carriageway`);
      const offsets = Array.from({ length: count }, (_, i) => HK.laneOffsetFor(road, dir, i));
      if (road.oneway) assert.ok(Math.abs(offsets[0] + offsets.at(-1)) < 1e-8, `${road.en} one-way lanes are not centred`);
      for (const offset of offsets) assert.ok(Math.abs(offset) <= available + 1e-8);
    }
  }
  const lanes = HK.buildLanes();
  assert.ok(lanes.every((lane) => lane.len > 20));
  assert.ok(lanes.filter((lane) => lane.road.source === 'landsd-osm').length > 100);
  assert.ok(HK.ROADS.filter((road) => road.traffic === false).every((road) => !lanes.some((lane) => lane.road === road)));
});

test('CWB teleport is on the real Yee Wo Street geometry', () => {
  const teleport = HK.TELEPORTS.find((entry) => entry.id === 'causeway');
  const nearest = HK.nearestRoad(teleport.x, teleport.z, 60);
  assert.ok(nearest);
  assert.equal(nearest.road.en, 'Yee Wo Street');
  assert.equal(nearest.road.source, 'landsd-osm-graph');
  assert.ok(nearest.dist < 8, `${nearest.dist} m from centreline`);
});

test('HK1980 conversion matches the documented Statue Square example', () => {
  const wgs = hk80GridToWgs84(834507, 815779);
  assert.ok(Math.abs(wgs.lat - 22.2808867) < 0.00001);
  assert.ok(Math.abs(wgs.lon - 114.1597790) < 0.00001);
  const world = hk80ToWorld(834507, 815779, 4, { groundHKPD: 4 });
  assert.ok(Math.abs(world.x - 183.34) < 0.1);
  assert.ok(Math.abs(world.z - 123.28) < 0.1);
  assert.equal(world.y, 0.15);
});

test('glTF bounds need no geometry buffer and preserve the vertical datum', () => {
  const doc = {
    scene: 0,
    scenes: [{ nodes: [0] }],
    nodes: [{ name: 'synthetic', mesh: 0, matrix: [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 834507, 4, -815779, 1] }],
    meshes: [{ primitives: [{ attributes: { POSITION: 0 } }] }],
    accessors: [{ min: [0, 0, 0], max: [10, 20, 10] }]
  };
  const box = boundsFromGltf(doc, { groundHKPD: 4 });
  assert.equal(box.name, 'synthetic');
  assert.ok(box.span > 9.9 && box.span < 10.1);
  assert.equal(box.minY, 0.15);
  assert.equal(box.maxY, 20.15);
  assert.ok(isBuildingGltf('BUILDING/B123/model.gltf'));
  assert.ok(!isBuildingGltf('TERRAIN/tile.gltf'));
});

function modelAt(file, x, z) {
  return { file, minX: x - 5, maxX: x + 5, minZ: z - 5, maxZ: z + 5, span: 10 };
}

test('model selection is capped, unique and balanced across north/core/Times Square', () => {
  const buildings = [];
  for (let i = 0; i < 4; i++) {
    buildings.push(modelAt(`north-${i}`, 2800 + i, 20));
    buildings.push(modelAt(`core-${i}`, 2650 + i, 200));
    buildings.push(modelAt(`south-${i}`, 2500 + i, 420));
  }
  const selected = selectCwbModels({ bounds: CWB.bounds, buildings }, 6);
  assert.equal(selected.length, 6);
  assert.equal(new Set(selected.map((entry) => entry.file)).size, 6);
  assert.equal(selected.filter((entry) => entry.file.startsWith('north')).length, 2);
  assert.equal(selected.filter((entry) => entry.file.startsWith('core')).length, 2);
  assert.equal(selected.filter((entry) => entry.file.startsWith('south')).length, 2);
  assert.equal(parseCwbModelCap('?cwbModels=0'), 0);
  assert.equal(parseCwbModelCap('?cwbModels=9999'), 240);
  assert.equal(parseCwbModelCap('?cwbModels=nonsense'), 48);
});

test('only overlapping successful models hide fallback parts', () => {
  const building = { id: 'b1', ring: [0, 0, 10, 0, 10, 10, 0, 10] };
  const hit = { file: 'hit.gltf', minX: 0, maxX: 10, minZ: 0, maxZ: 10 };
  const miss = { file: 'miss.gltf', minX: 100, maxX: 110, minZ: 100, maxZ: 110 };
  const result = matchCwbBuildingModels([hit, miss], [building]);
  assert.deepEqual([...result.hiddenBuildingIds], ['b1']);
  assert.deepEqual([...result.matchedFiles], ['hit.gltf']);
  const none = matchCwbBuildingModels([miss], [building]);
  assert.equal(none.hiddenBuildingIds.size, 0, 'a missing/failed model cannot remove the fallback');
});

test('marking trim cuts exact distances without changing the remaining line', () => {
  const trimmed = trimPolyline([{ x: 0, z: 0 }, { x: 10, z: 0 }], 2, 3);
  assert.deepEqual(trimmed, [{ x: 2, z: 0 }, { x: 7, z: 0 }]);
  assert.deepEqual(trimPolyline([{ x: 0, z: 0 }, { x: 2, z: 0 }], 2, 2), []);
});

test('concave real footprints do not create invisible OBB walls across empty space', () => {
  const collider = { ring: [0, 0, 10, 0, 10, 4, 4, 4, 4, 10, 0, 10], holes: [] };
  const clear = { x: 8, z: 8 };
  assert.equal(resolveCircleAgainstFootprint(clear, collider, 1.35), false);
  assert.deepEqual(clear, { x: 8, z: 8 }, 'the missing quadrant of an L must remain open');

  const nearEdge = { x: -0.5, z: 2 };
  assert.equal(resolveCircleAgainstFootprint(nearEdge, collider, 1), true);
  assert.ok(Math.abs(nearEdge.x + 1) < 1e-5 && Math.abs(nearEdge.z - 2) < 1e-5);

  const inside = { x: 2, z: 2 };
  assert.equal(resolveCircleAgainstFootprint(inside, collider, 1), true);
  assert.equal(pointInFlatRing(inside.x, inside.z, collider.ring), false, 'depenetration leaves the solid');
});

test('footprint courtyard holes stay open and their edges still collide', () => {
  const collider = {
    ring: [0, 0, 10, 0, 10, 10, 0, 10],
    holes: [[3, 3, 3, 7, 7, 7, 7, 3]]
  };
  const clear = { x: 5, z: 5 };
  assert.equal(resolveCircleAgainstFootprint(clear, collider, 1), false);
  const nearHoleEdge = { x: 3.5, z: 5 };
  assert.equal(resolveCircleAgainstFootprint(nearHoleEdge, collider, 1), true);
  assert.ok(nearHoleEdge.x > 3.99 && nearHoleEdge.x < 4.01);
});

test('CWB traffic centre samples never start inside a ground-level real footprint', () => {
  const ground = CWB.buildings.filter((building) => building.base < 1.8);
  const lanes = HK.buildLanes().filter((lane) => lane.road.source === 'landsd-osm');
  for (const lane of lanes) {
    for (let s = 0; s <= lane.len; s += 12) {
      const pose = HK.poseAt(lane, s);
      assert.ok(ground.every((building) => !pointInFlatRing(pose.x, pose.z, building.ring)),
        `${lane.road.id} lane ${lane.lane} dir ${lane.dir} enters a building at ${s.toFixed(1)} m`);
    }
  }
});

test('AI drops only the two lanes with insufficient real-footprint clearance', () => {
  const lanes = HK.buildLanes();
  const colliders = causewayBayBuildingColliders(CWB.buildings);
  const filtered = filterFootprintClearanceLanes(lanes, colliders, HK.poseAt);
  assert.deepEqual(filtered.dropped.map(({ lane }) => `${lane.road.id}:${lane.dir}:${lane.lane}`).sort(), [
    'cwb-r7617-0:1:0',
    'cwb-r7681-0:1:3'
  ]);
  assert.equal(filterFootprintClearanceLanes(filtered.lanes, colliders, HK.poseAt).dropped.length, 0);
  assert.ok(filtered.lanes.some((lane) => lane.road.id === 'cwb-r7681-0' && lane.lane < 3),
    'safe Canal Road East lanes remain available to traffic');
});
