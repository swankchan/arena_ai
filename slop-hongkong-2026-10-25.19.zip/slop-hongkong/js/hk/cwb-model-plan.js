// Pure planning helpers for optional CWB Individualised models. No three.js
// import: data selection and fallback matching can be tested on a bare checkout.

const DEFAULT_CAP = 48;
const ZONES = [
  { key: 'north', test: (entry) => centre(entry).z < 80, anchor: { x: 2820, z: 150 } },
  { key: 'core', test: (entry) => centre(entry).z >= 80 && centre(entry).z < 330, anchor: { x: 2670, z: 220 } },
  { key: 'south', test: (entry) => centre(entry).z >= 330, anchor: { x: 2520, z: 410 } }
];

function centre(entry) {
  return { x: (entry.minX + entry.maxX) / 2, z: (entry.minZ + entry.maxZ) / 2 };
}

function intersects(entry, bounds, margin = 12) {
  return entry.maxX >= bounds.minX - margin && entry.minX <= bounds.maxX + margin
    && entry.maxZ >= bounds.minZ - margin && entry.minZ <= bounds.maxZ + margin;
}

export function parseCwbModelCap(search = '') {
  const value = new URLSearchParams(search).get('cwbModels');
  if (value == null || value === '') return DEFAULT_CAP;
  const number = Number(value);
  if (!Number.isFinite(number)) return DEFAULT_CAP;
  return Math.max(0, Math.min(240, Math.floor(number)));
}

/** Balance north / core / Times Square instead of spending the cap at one junction. */
export function selectCwbModels(manifest, cap = DEFAULT_CAP) {
  const bounds = manifest?.bounds;
  if (!bounds || !(cap > 0)) return [];
  const candidates = (manifest.buildings || []).filter((entry) => (
    entry?.file && Number.isFinite(entry.minX) && intersects(entry, bounds) && entry.span >= 4
  ));
  const zones = ZONES.map((zone) => candidates.filter((entry) => zone.test(entry)).sort((a, b) => {
    const ca = centre(a);
    const cb = centre(b);
    const da = Math.hypot(ca.x - zone.anchor.x, ca.z - zone.anchor.z);
    const db = Math.hypot(cb.x - zone.anchor.x, cb.z - zone.anchor.z);
    return da - db || String(a.file).localeCompare(String(b.file));
  }));
  const selected = [];
  const selectedFiles = new Set();
  for (let i = 0; selected.length < cap; i++) {
    let added = false;
    for (const zone of zones) {
      if (i < zone.length && selected.length < cap && !selectedFiles.has(zone[i].file)) {
        selected.push(zone[i]);
        selectedFiles.add(zone[i].file);
        added = true;
      }
    }
    if (!added) break;
  }
  return selected;
}

function buildingBounds(building) {
  const box = { minX: Infinity, maxX: -Infinity, minZ: Infinity, maxZ: -Infinity };
  for (let i = 0; i + 1 < building.ring.length; i += 2) {
    box.minX = Math.min(box.minX, building.ring[i]);
    box.maxX = Math.max(box.maxX, building.ring[i]);
    box.minZ = Math.min(box.minZ, building.ring[i + 1]);
    box.maxZ = Math.max(box.maxZ, building.ring[i + 1]);
  }
  return box;
}

function overlapRatio(a, b) {
  const width = Math.max(0, Math.min(a.maxX, b.maxX) - Math.max(a.minX, b.minX));
  const depth = Math.max(0, Math.min(a.maxZ, b.maxZ) - Math.max(a.minZ, b.minZ));
  const intersection = width * depth;
  const areaA = Math.max(0.01, (a.maxX - a.minX) * (a.maxZ - a.minZ));
  const areaB = Math.max(0.01, (b.maxX - b.minX) * (b.maxZ - b.minZ));
  return intersection / Math.min(areaA, areaB);
}

/** Only successfully loaded models are passed here, so failures keep fallback. */
export function matchCwbBuildingModels(entries, buildings) {
  const hiddenBuildingIds = new Set();
  const matchedFiles = new Set();
  const bounds = buildings.map((building) => ({ building, box: buildingBounds(building) }));
  for (const entry of entries) {
    for (const { building, box } of bounds) {
      if (overlapRatio(entry, box) < 0.12) continue;
      hiddenBuildingIds.add(building.id);
      matchedFiles.add(entry.file);
    }
  }
  return { hiddenBuildingIds, matchedFiles };
}
