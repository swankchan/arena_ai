#!/usr/bin/env node
// Exact centreline-segment / ground-footprint audit for the CWB pilot.
// A negative clearance means the derived carriageway intersects a real footprint.
// This is a diagnostic, not a licence to move official buildings to fit roads.
import * as HK from '../../js/hk/config.js';
const B = HK.CWB_BOUNDS;
const buildings = HK.CWB_BUILDINGS.filter((b) => b.base < 1.8).map((b) => {
  let minX=Infinity,maxX=-Infinity,minZ=Infinity,maxZ=-Infinity;
  for(let i=0;i<b.ring.length;i+=2){minX=Math.min(minX,b.ring[i]);maxX=Math.max(maxX,b.ring[i]);minZ=Math.min(minZ,b.ring[i+1]);maxZ=Math.max(maxZ,b.ring[i+1]);}
  return {...b,minX,maxX,minZ,maxZ};
});
function inside(x,z,ring){let yes=false;for(let i=0,j=ring.length-2;i<ring.length;j=i,i+=2){const xi=ring[i],zi=ring[i+1],xj=ring[j],zj=ring[j+1];if((zi>z)!==(zj>z)&&x<(xj-xi)*(z-zi)/(zj-zi)+xi)yes=!yes;}return yes;}
function pointSeg(px,pz,ax,az,bx,bz){const dx=bx-ax,dz=bz-az,l=dx*dx+dz*dz||1e-9,t=Math.max(0,Math.min(1,((px-ax)*dx+(pz-az)*dz)/l));return Math.hypot(px-ax-dx*t,pz-az-dz*t);}
function orient(ax,az,bx,bz,cx,cz){return (bx-ax)*(cz-az)-(bz-az)*(cx-ax);}
function intersects(a,b,c,d){const o1=orient(a.x,a.z,b.x,b.z,c.x,c.z),o2=orient(a.x,a.z,b.x,b.z,d.x,d.z),o3=orient(c.x,c.z,d.x,d.z,a.x,a.z),o4=orient(c.x,c.z,d.x,d.z,b.x,b.z);return o1*o2<=0&&o3*o4<=0;}
function segDistance(a,b,c,d){if(intersects(a,b,c,d))return 0;return Math.min(pointSeg(a.x,a.z,c.x,c.z,d.x,d.z),pointSeg(b.x,b.z,c.x,c.z,d.x,d.z),pointSeg(c.x,c.z,a.x,a.z,b.x,b.z),pointSeg(d.x,d.z,a.x,a.z,b.x,b.z));}
function distanceToRing(a,b,ring){let best=Infinity;for(let i=0,j=ring.length-2;i<ring.length;j=i,i+=2){best=Math.min(best,segDistance(a,b,{x:ring[j],z:ring[j+1]},{x:ring[i],z:ring[i+1]}));if(best===0)return 0;}return best;}
const hits=[];let pairs=0;
for(const road of HK.ROADS){
  if(!road.pts.some(p=>p.x>=B.minX-30&&p.x<=B.maxX+30&&p.z>=B.minZ-30&&p.z<=B.maxZ+30))continue;
  for(const building of buildings){
    if(!road.pts.some(p=>p.x>=building.minX-15&&p.x<=building.maxX+15&&p.z>=building.minZ-15&&p.z<=building.maxZ+15))continue;
    pairs++;
    let best=Infinity;
    for(let i=1;i<road.pts.length;i++){
      const a=road.pts[i-1],b=road.pts[i];
      if(inside(a.x,a.z,building.ring)||inside(b.x,b.z,building.ring)){best=0;break;}
      best=Math.min(best,distanceToRing(a,b,building.ring));
    }
    const clearance=best-road.w/2;
    if(clearance<0)hits.push({road:road.en,id:road.id,building:building.name||building.id,buildingId:building.id,clearance:+clearance.toFixed(2),centreDistance:+best.toFixed(2),halfWidth:road.w/2});
  }
}
hits.sort((a,b)=>a.clearance-b.clearance);
console.log(JSON.stringify({groundBuildings:buildings.length,candidatePairs:pairs,overlapPairs:hits.length,roads:new Set(hits.map(h=>h.id)).size,buildings:new Set(hits.map(h=>h.buildingId)).size,worst:hits.slice(0,40)},null,2));
