// Verify the real local LandsD 11-SW-10C glTF packages without a GPU.
// usage: node tools/hk/verify-10c-assets.mjs --require-complete
// optional: --compare-source /path/to/flat/drive-downloads --expect-digest SHA256

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { boundsFromGltf } from '../../js/hk/hk80.js';

const args = process.argv.slice(2);
const valueAfter = (flag) => {
  const index = args.indexOf(flag);
  return index >= 0 ? args[index + 1] : null;
};
const requireComplete = args.includes('--require-complete');
const compareSource = valueAfter('--compare-source');
const expectedDigest = valueAfter('--expect-digest');
const manifestPath = path.resolve(valueAfter('--manifest') || 'hk-3d/manifest.json');
const root = path.dirname(manifestPath);
const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
const allowedCategories = new Set(['BUILDING', 'INFRASTRUCTURE', 'INFRASTRUCTURE(TB)', 'TERRAIN(TB)', 'WATERBODY', 'VEGETATION(TB)', 'GENERIC']);
const expectedCategories = {
  BUILDING: 151, INFRASTRUCTURE: 12, 'INFRASTRUCTURE(TB)': 1,
  'TERRAIN(TB)': 1, WATERBODY: 3, 'VEGETATION(TB)': 1, GENERIC: 1
};
const resources = new Map();
const categories = {};
const seenFiles = new Set();
let buffers = 0;
let images = 0;

function localPath(relative) {
  const normal = path.posix.normalize(String(relative).replace(/\\/g, '/'));
  if (!normal || normal.startsWith('/') || normal === '..' || normal.startsWith('../')) {
    throw new Error(`unsafe resource path: ${relative}`);
  }
  return normal;
}

function addResource(relative) {
  const normal = localPath(relative);
  if (!resources.has(normal)) {
    const absolute = path.join(root, ...normal.split('/'));
    if (!fs.existsSync(absolute)) throw new Error(`missing resource: ${normal}`);
    resources.set(normal, absolute);
  }
  return resources.get(normal);
}

for (const entry of manifest.buildings || []) {
  if (!entry.file || seenFiles.has(entry.file)) throw new Error(`duplicate/empty manifest file: ${entry.file}`);
  seenFiles.add(entry.file);
  if (!allowedCategories.has(entry.category)) throw new Error(`${entry.file}: invalid category ${entry.category}`);
  categories[entry.category] = (categories[entry.category] || 0) + 1;
  const gltfPath = addResource(entry.file);
  const gltf = JSON.parse(fs.readFileSync(gltfPath, 'utf8'));
  for (const buffer of gltf.buffers || []) {
    if (!buffer.uri || buffer.uri.startsWith('data:')) continue;
    const bufferPath = addResource(path.posix.join(path.posix.dirname(entry.file), decodeURIComponent(buffer.uri)));
    const actual = fs.statSync(bufferPath).size;
    if (actual !== buffer.byteLength) throw new Error(`${entry.file}: ${buffer.uri} has ${actual} bytes, expected ${buffer.byteLength}`);
    buffers++;
  }
  for (const image of gltf.images || []) {
    if (!image.uri || image.uri.startsWith('data:')) continue;
    const imagePath = addResource(path.posix.join(path.posix.dirname(entry.file), decodeURIComponent(image.uri)));
    const data = fs.readFileSync(imagePath);
    const png = data.length > 8 && data[0] === 0x89 && data[1] === 0x50;
    const jpeg = data.length > 3 && data[0] === 0xff && data[1] === 0xd8;
    if (!png && !jpeg) throw new Error(`${entry.file}: ${image.uri} is not PNG/JPEG`);
    images++;
  }
  const actual = boundsFromGltf(gltf, {
    frame: manifest.frame,
    groundHKPD: manifest.groundHKPD,
    groundY: manifest.groundY
  });
  for (const key of ['minX', 'maxX', 'minZ', 'maxZ', 'minY', 'maxY']) {
    if (!Number.isFinite(entry[key]) || Math.abs(actual[key] - entry[key]) > 0.05) {
      throw new Error(`${entry.file}: manifest ${key}=${entry[key]}, actual=${actual[key]}`);
    }
  }
}

const digest = crypto.createHash('sha256');
let bytes = 0;
let sourceCompared = 0;
for (const [relative, absolute] of [...resources.entries()].sort(([a], [b]) => a.localeCompare(b))) {
  const data = fs.readFileSync(absolute);
  bytes += data.length;
  digest.update(relative);
  digest.update('\0');
  digest.update(String(data.length));
  digest.update('\0');
  digest.update(data);
  if (compareSource) {
    const source = path.join(path.resolve(compareSource), path.basename(relative));
    if (!fs.existsSync(source) || !data.equals(fs.readFileSync(source))) throw new Error(`source byte mismatch: ${relative}`);
    sourceCompared++;
  }
}

const models = seenFiles.size;
if (requireComplete) {
  if (models !== 170 || resources.size !== 748 || bytes !== 896027196) {
    throw new Error(`incomplete sheet: ${models} models / ${resources.size} resources / ${bytes} bytes`);
  }
  for (const [category, count] of Object.entries(expectedCategories)) {
    if (categories[category] !== count) throw new Error(`${category}: ${categories[category] || 0} != ${count}`);
  }
}
const report = {
  models,
  categories,
  resources: resources.size,
  bytes,
  buffers,
  images,
  sourceCompared,
  sha256: digest.digest('hex')
};
if (expectedDigest && report.sha256 !== expectedDigest) throw new Error(`digest ${report.sha256} != ${expectedDigest}`);
console.log(JSON.stringify(report, null, 2));
