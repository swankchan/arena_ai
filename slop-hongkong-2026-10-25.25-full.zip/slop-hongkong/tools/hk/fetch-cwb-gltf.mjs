#!/usr/bin/env node
// Download and subset official LandsD Individualised glTF for Causeway Bay.
// Run this on a network that can reach download.map.gov.hk. No API key is sent
// unless the public endpoint answers 401. Large ZIPs are never committed.
//
//   node tools/hk/fetch-cwb-gltf.mjs
//   node tools/hk/fetch-cwb-gltf.mjs --sheet 11-SW-10D
//   node tools/hk/fetch-cwb-gltf.mjs --sheet 11-SW-10D --sheet 11-SW-15B --keep-zip

import { spawnSync } from 'node:child_process';
import { existsSync, mkdirSync, readFileSync, readdirSync, rmSync, statSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { CWB } from '../../js/hk/cwb-geodata.js';
import { boundsFromGltf, isBuildingGltf } from '../../js/hk/hk80.js';

const ROOT = fileURLToPath(new URL('../..', import.meta.url));
const ZIP_URL = 'https://download.map.gov.hk/api/3d-zip/GLTF';
const DEFAULT_SHEETS = ['11-SW-10D', '11-SW-15B', '11-SW-10C', '11-SW-15A'];
const SHEET_RE = /^[0-9]{1,2}-[NS][EW]-[0-9]{1,2}[A-D]$/i;
const ATTRIBUTION = '© Government of the Hong Kong SAR (Lands Department) / Open3Dhk (https://3d.map.gov.hk/)';

function parseArgs(argv) {
  const opts = { sheets: [], out: path.join(ROOT, 'hk-3d'), keepZip: false, minSpan: 6, help: false };
  for (let i = 2; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === '--help' || arg === '-h') opts.help = true;
    else if (arg === '--keep-zip') opts.keepZip = true;
    else if (arg === '--sheet') opts.sheets.push(...String(argv[++i] || '').split(','));
    else if (arg === '--out') opts.out = path.resolve(argv[++i] || opts.out);
    else if (arg === '--min-span') opts.minSpan = Number(argv[++i]);
    else throw new Error(`Unknown argument ${arg}`);
  }
  if (!opts.sheets.length) opts.sheets = DEFAULT_SHEETS;
  opts.sheets = [...new Set(opts.sheets.map((sheet) => {
    const id = sheet.trim().toUpperCase();
    if (!SHEET_RE.test(id)) throw new Error(`Bad sheet ${sheet}`);
    return id;
  }))];
  if (!(opts.minSpan >= 0 && opts.minSpan < 100)) throw new Error('--min-span must be between 0 and 100 m');
  return opts;
}

function run(command, args, options = {}) {
  const result = spawnSync(command, args, { encoding: 'utf8', ...options });
  if (result.error) throw result.error;
  if (result.status !== 0) throw new Error(`${command} exited ${result.status}: ${result.stderr || result.stdout || ''}`);
  return result;
}

function download(url, destination) {
  mkdirSync(path.dirname(destination), { recursive: true });
  const result = spawnSync('curl', [
    '-sS', '-L', '--retry', '5', '--retry-all-errors', '--retry-delay', '2',
    '-C', '-', '-o', destination, '-w', '%{http_code}', url
  ], { encoding: 'utf8' });
  if (result.error) throw result.error;
  const code = Number(String(result.stdout || '').trim());
  if (code === 416 && existsSync(destination)) return 200;
  if (code === 401) {
    rmSync(destination, { force: true });
    return 401;
  }
  if (result.status !== 0 || (code !== 200 && code !== 206)) {
    // Error HTML is not resumable ZIP data. A network interruption without an
    // HTTP response keeps its partial file for the next `curl -C -` run.
    if (code >= 400) rmSync(destination, { force: true });
    throw new Error(`Download failed (${code}, curl ${result.status}): ${url}\n${result.stderr || ''}`);
  }
  return code;
}

async function publicDownloadKey() {
  for (const page of ['https://3d.map.gov.hk/download-api?l=zh-HK', 'https://3d.map.gov.hk/download-api']) {
    try {
      const response = await fetch(page);
      const html = await response.text();
      const match = html.match(/[?&]key=([A-Za-z0-9_-]{8,})/);
      if (match) return match[1];
    } catch {
      // Try the next public page; a clear error follows if no key is available.
    }
  }
  return '';
}

async function fetchSheet(sheet, destination) {
  const plain = `${ZIP_URL}/${sheet}.zip`;
  let code = download(plain, destination);
  if (code === 401) {
    const key = await publicDownloadKey();
    if (!key) throw new Error(`${sheet} needs a download key; no public key was found on the LandsD download page`);
    // curl may have written the 401 HTML body. Never resume a ZIP from that
    // byte count: the keyed response must start from a clean file.
    rmSync(destination, { force: true });
    code = download(`${plain}?key=${encodeURIComponent(key)}`, destination);
  }
  return plain;
}

function listZip(zipPath) {
  const result = run('unzip', ['-Z1', zipPath], { maxBuffer: 256 * 1024 * 1024 });
  return result.stdout.split(/\r?\n/).filter(Boolean);
}

function extract(zipPath, destination, entries) {
  if (!entries.length) return;
  mkdirSync(destination, { recursive: true });
  for (let i = 0; i < entries.length; i += 100) {
    run('unzip', ['-q', '-o', '-d', destination, zipPath, ...entries.slice(i, i + 100)], { maxBuffer: 64 * 1024 * 1024 });
  }
}

function walk(directory) {
  const out = [];
  for (const entry of readdirSync(directory)) {
    const full = path.join(directory, entry);
    if (statSync(full).isDirectory()) out.push(...walk(full));
    else out.push(full);
  }
  return out;
}

function overlapsPilot(entry, margin = 24) {
  const box = CWB.bounds;
  return entry.maxX >= box.minX - margin && entry.minX <= box.maxX + margin
    && entry.maxZ >= box.minZ - margin && entry.minZ <= box.maxZ + margin;
}

function parentPrefix(file) {
  const index = file.lastIndexOf('/');
  return index < 0 ? '' : file.slice(0, index + 1);
}

async function processSheet(sheet, opts) {
  const downloadDir = path.join(opts.out, '.cwb-download');
  const zipPath = path.join(downloadDir, `${sheet}.zip`);
  const surveyDir = path.join(downloadDir, `${sheet}-survey`);
  const destination = path.join(opts.out, sheet);
  console.log(`[cwb] ${sheet}: downloading official glTF ZIP`);
  const source = await fetchSheet(sheet, zipPath);
  const names = listZip(zipPath);
  const gltfs = names.filter(isBuildingGltf);
  console.log(`[cwb] ${sheet}: ${gltfs.length} BUILDING glTF files; surveying bounds`);
  rmSync(surveyDir, { recursive: true, force: true });
  extract(zipPath, surveyDir, gltfs);

  const kept = [];
  let overlap = 0;
  for (const file of walk(surveyDir)) {
    if (!isBuildingGltf(file)) continue;
    const relative = path.relative(surveyDir, file).split(path.sep).join('/');
    try {
      const doc = JSON.parse(readFileSync(file, 'utf8'));
      const bounds = boundsFromGltf(doc, { groundHKPD: CWB.groundHKPD, groundY: 0.15 });
      if (!overlapsPilot(bounds)) continue;
      overlap++;
      if (bounds.span < opts.minSpan) continue;
      kept.push({ file: `${sheet}/${relative}`, sheet, ...bounds });
    } catch (error) {
      console.warn(`[cwb] ${sheet}: skip ${relative}: ${error.message}`);
    }
  }

  const prefixes = new Set(kept.map((entry) => parentPrefix(entry.file.slice(sheet.length + 1))).filter(Boolean));
  const resources = names.filter((name) => {
    if (name.toLowerCase().endsWith('.gltf')) return false;
    const normal = name.replace(/\\/g, '/');
    for (const prefix of prefixes) if (normal.startsWith(prefix)) return true;
    return false;
  });
  const keptOriginalNames = new Set(kept.map((entry) => entry.file.slice(sheet.length + 1)));
  const selectedGltfs = gltfs.filter((name) => keptOriginalNames.has(name.replace(/\\/g, '/')));
  rmSync(destination, { recursive: true, force: true });
  extract(zipPath, destination, [...selectedGltfs, ...resources]);
  rmSync(surveyDir, { recursive: true, force: true });
  if (!opts.keepZip) rmSync(zipPath, { force: true });
  console.log(`[cwb] ${sheet}: ${overlap} intersect pilot; kept ${kept.length} (span ≥ ${opts.minSpan} m)`);
  return { sheet, source, buildingFiles: gltfs.length, overlap, kept: kept.length, buildings: kept };
}

async function main() {
  const opts = parseArgs(process.argv);
  if (opts.help) {
    console.log(`Usage: node tools/hk/fetch-cwb-gltf.mjs [--sheet SHEET ...] [--out hk-3d] [--min-span 6] [--keep-zip]\n\nDefault sheets: ${DEFAULT_SHEETS.join(', ')}\nOutput: hk-3d/manifest.json plus only the selected BUILDING model resources.`);
    return;
  }
  const outputDir = opts.out;
  mkdirSync(outputDir, { recursive: true });
  const manifestPath = path.join(outputDir, 'manifest.json');
  let previous = { buildings: [], sources: [] };
  if (existsSync(manifestPath)) {
    try { previous = JSON.parse(readFileSync(manifestPath, 'utf8')); } catch { previous = { buildings: [], sources: [] }; }
  }
  const processed = new Set(opts.sheets);
  const reports = [];
  for (const sheet of opts.sheets) reports.push(await processSheet(sheet, opts));
  const buildings = [
    ...(previous.buildings || []).filter((entry) => !processed.has(entry.sheet)),
    ...reports.flatMap((report) => report.buildings)
  ];
  const oldSources = (previous.sources || []).filter((entry) => !processed.has(entry.sheet));
  const sources = [...oldSources, ...reports.map(({ buildings: ignored, ...report }) => report)];
  const manifest = {
    version: 1,
    district: 'causeway-bay',
    bounds: CWB.bounds,
    groundHKPD: CWB.groundHKPD,
    groundY: 0.15,
    frame: { originLat: 22.282, originLon: 114.158, mPerDegLat: 110734.08, mPerDegLon: 103056.75 },
    crs: 'EPSG:2326 → WGS84 → application metres',
    attribution: ATTRIBUTION,
    generatedAt: new Date().toISOString(),
    minSpan: opts.minSpan,
    counts: { buildings: buildings.length, sheets: sources.length },
    sources,
    buildings
  };
  writeFileSync(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`);
  console.log(`[cwb] manifest ${manifestPath}: ${buildings.length} models from ${sources.length} sheets`);
  console.log('[cwb] keep the LandsD / Open3Dhk attribution visible when publishing the app.');
}

main().catch((error) => {
  console.error(error.stack || error.message || error);
  process.exit(1);
});
