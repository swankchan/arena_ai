#!/usr/bin/env node
// Build the compact Causeway Bay pilot from a LandsD/OSM geodata pack.
//
// Usage:
//   node tools/hk/build-cwb-pilot.mjs --source /path/to/hk-geodata.js
//
// The source pack is keithligh/slop-hongkong at the commit recorded below. Its
// roads combine LandsD Road Centreline geometry with OSM class/lanes/width;
// buildings are LandsD footprints, BaseHeight and TopHeight. This script only
// cuts and reprojects that data. It does not invent survey markings or heights.

import { pathToFileURL, fileURLToPath } from 'node:url';
import { writeFileSync } from 'node:fs';
import path from 'node:path';

const ROOT = fileURLToPath(new URL('../..', import.meta.url));
const OUT = path.join(ROOT, 'js/hk/cwb-geodata.js');
const SOURCE_COMMIT = '17e0afe849507f6af0e19f58b56a2c2116b11886';
const SOURCE_URL = 'https://github.com/keithligh/slop-hongkong';

// Current application frame (tools/hk/frame.mjs). The source frame is stored in
// GEO.frame and is converted through WGS84 rather than shifted by eye.
const DEST = { lat: 22.282, lon: 114.158, mpdLat: 110734.08, mpdLon: 103056.75 };
const A = 6378137;
const E2 = 6.69437999014e-3;
function metresPerDegree(lat) {
  const phi = lat * Math.PI / 180;
  const sin = Math.sin(phi);
  const n = A / Math.sqrt(1 - E2 * sin * sin);
  const m = A * (1 - E2) / (1 - E2 * sin * sin) ** 1.5;
  return {
    lon: Math.PI / 180 * n * Math.cos(phi),
    lat: Math.PI / 180 * m
  };
}

// Includes Victoria Park's south edge, SOGO / Hysan, and Times Square.
const BOUNDS = Object.freeze({ minX: 2220, maxX: 3020, minZ: -380, maxZ: 520 });
const GROUND_HKPD = 4;
const round = (v, digits = 1) => Math.round(v * 10 ** digits) / 10 ** digits;

const NAMES_ZH = {
  'GLOUCESTER ROAD': '告士打道',
  'HENNESSY ROAD': '軒尼詩道',
  'YEE WO STREET': '怡和街',
  'CAUSEWAY ROAD': '高士威道',
  'LEIGHTON ROAD': '禮頓道',
  'PERCIVAL STREET': '波斯富街',
  'RUSSELL STREET': '羅素街',
  "JARDINE'S BAZAAR": '渣甸坊',
  'LOCKHART ROAD': '駱克道',
  'JAFFE ROAD': '謝斐道',
  'WAN CHAI ROAD': '灣仔道',
  'LEE GARDEN ROAD': '利園山道',
  'HYSAN AVENUE': '希慎道',
  'MATHESON STREET': '勿地臣街',
  'SHARP STREET EAST': '霎東街',
  'SHARP STREET WEST': '霎西街',
  'KAI CHIU ROAD': '啟超道',
  'PENNINGTON STREET': '邊寧頓街',
  'PATERSON STREET': '百德新街',
  'CLEVELAND STREET': '加寧街',
  'KINGSTON STREET': '京士頓街',
  'EAST POINT ROAD': '東角道',
  'GREAT GEORGE STREET': '記利佐治街',
  'LAN FONG ROAD': '蘭芳道',
  'SUN WUI ROAD': '新會道',
  'SUNNING ROAD': '新寧道',
  'IRVING STREET': '伊榮街',
  'TANG LUNG STREET': '登龍街',
  'YUN PING ROAD': '恩平道',
  'BOWRINGTON ROAD': '寶靈頓道',
  'CAROLINE HILL ROAD': '加路連山道',
  'MORRISON HILL ROAD': '摩理臣山道',
  'WONG NAI CHUNG ROAD': '黃泥涌道',
  'VICTORIA PARK ROAD': '維園道',
  'HUNG HING ROAD': '鴻興道',
  'MARSH ROAD': '馬師道',
  'CANAL ROAD EAST': '堅拿道東',
  'CANAL ROAD WEST': '堅拿道西',
  'SUGAR STREET': '糖街',
  'HAVEN STREET': '希雲街',
  'PAK SHA ROAD': '白沙道',
  'FOO MING STREET': '富明街',
  'HOI PING ROAD': '開平道',
  'YIU WA STREET': '耀華街',
  'TIN LOK LANE': '天樂里',
  'YAT SIN STREET': '日善街',
  'LEIGHTON LANE': '禮頓里'
};

const TRUNK = /GLOUCESTER|VICTORIA PARK|CAUSEWAY ROAD|WONG NAI CHUNG|CAROLINE HILL|HUNG HING/;
const PRIMARY = /HENNESSY|YEE WO|LEIGHTON ROAD|PERCIVAL|LOCKHART|JAFFE|WAN CHAI ROAD/;
const EXCLUDED = /FLYOVER|TUNNEL|INTERCHANGE/i;

function englishName(raw) {
  if (!raw) return 'Unnamed road';
  const english = raw.replace(/^[^A-Za-z]*/, '').trim() || raw;
  if (/[\u4e00-\u9fff]/.test(raw)) {
    const match = raw.match(/[A-Za-z][A-Za-z0-9' .-]*$/);
    if (match) return match[0].trim().replace(/\b\w/g, (c) => c.toUpperCase());
  }
  return english.toLowerCase().replace(/\b\w/g, (c) => c.toUpperCase()).replace(/'S\b/g, "'s");
}

function chineseName(raw, english) {
  const match = String(raw || '').match(/^[\u4e00-\u9fff]+/);
  if (match) return match[0];
  return NAMES_ZH[String(raw || '').toUpperCase()] || (raw ? english : '未命名道路');
}

function roadClass(raw, highway) {
  const name = String(raw || '').toUpperCase();
  if (highway || TRUNK.test(name)) return 'trunk';
  if (PRIMARY.test(name)) return 'primary';
  return 'secondary';
}

// Liang–Barsky clip of one segment to the pilot rectangle.
function clipSegment(a, b, box = BOUNDS) {
  const dx = b.x - a.x;
  const dz = b.z - a.z;
  let t0 = 0;
  let t1 = 1;
  const p = [-dx, dx, -dz, dz];
  const q = [a.x - box.minX, box.maxX - a.x, a.z - box.minZ, box.maxZ - a.z];
  for (let i = 0; i < 4; i++) {
    if (Math.abs(p[i]) < 1e-12) {
      if (q[i] < 0) return null;
      continue;
    }
    const t = q[i] / p[i];
    if (p[i] < 0) t0 = Math.max(t0, t);
    else t1 = Math.min(t1, t);
    if (t0 > t1) return null;
  }
  return [
    { x: a.x + dx * t0, z: a.z + dz * t0 },
    { x: a.x + dx * t1, z: a.z + dz * t1 }
  ];
}

function clipPolyline(points) {
  const pieces = [];
  let current = [];
  for (let i = 0; i + 1 < points.length; i++) {
    const clipped = clipSegment(points[i], points[i + 1]);
    if (!clipped) {
      if (current.length > 1) pieces.push(current);
      current = [];
      continue;
    }
    const [a, b] = clipped;
    if (!current.length) current = [a, b];
    else {
      const last = current[current.length - 1];
      if (Math.hypot(last.x - a.x, last.z - a.z) < 0.02) current.push(b);
      else {
        if (current.length > 1) pieces.push(current);
        current = [a, b];
      }
    }
  }
  if (current.length > 1) pieces.push(current);
  return pieces.map((piece) => piece.filter((p, i, all) => {
    if (!i) return true;
    const prev = all[i - 1];
    return Math.hypot(p.x - prev.x, p.z - prev.z) > 0.02;
  })).filter((piece) => piece.length > 1);
}

function carriagewayWidth(w, lanes, highway) {
  const tagged = Number.isFinite(+w) ? +w : 0;
  const count = Math.max(0, Math.round(+lanes) || 0);
  const fromLanes = count ? count * 3.05 : 0;
  let floor = 3.6;
  if (count >= 4) floor = 9.6;
  else if (count >= 3) floor = 7.8;
  else if (count >= 2) floor = 5.8;
  const value = highway ? Math.max(10.5, tagged, fromLanes) : tagged >= 3.2 ? tagged : Math.max(floor, fromLanes);
  return Math.min(22, round(value || 3.6));
}

function ringCentre(ring) {
  let x = 0;
  let z = 0;
  const count = ring.length / 2;
  for (let i = 0; i < ring.length; i += 2) {
    x += ring[i];
    z += ring[i + 1];
  }
  return { x: x / count, z: z / count };
}

function ringArea(ring) {
  let area = 0;
  for (let i = 0, j = ring.length - 2; i < ring.length; j = i, i += 2) {
    area += ring[j] * ring[i + 1] - ring[i] * ring[j + 1];
  }
  return Math.abs(area / 2);
}

function parseArgs(argv) {
  const opts = { source: '', out: OUT };
  for (let i = 2; i < argv.length; i++) {
    if (argv[i] === '--source') opts.source = path.resolve(argv[++i] || '');
    else if (argv[i] === '--out') opts.out = path.resolve(argv[++i] || opts.out);
    else throw new Error(`Unknown argument: ${argv[i]}`);
  }
  if (!opts.source) throw new Error('--source /path/to/hk-geodata.js is required');
  return opts;
}

const opts = parseArgs(process.argv);
const { GEO } = await import(pathToFileURL(opts.source).href);
const sourceFrame = GEO.frame || {};
const sourceLat = sourceFrame.lat0 ?? sourceFrame.originLat;
const sourceLon = sourceFrame.lon0 ?? sourceFrame.originLon;
if (!Number.isFinite(sourceLat) || !Number.isFinite(sourceLon)) throw new Error('Source GEO.frame has no lat0/lon0 or originLat/originLon');
const sourceMpd = metresPerDegree(sourceLat);

function toDest(x, z) {
  const lon = sourceLon + x / sourceMpd.lon;
  const lat = sourceLat - z / sourceMpd.lat;
  return {
    x: (lon - DEST.lon) * DEST.mpdLon,
    z: (DEST.lat - lat) * DEST.mpdLat
  };
}

const roads = [];
GEO.roads.forEach((r, sourceIndex) => {
  const [rawName, rawWidth, dir, rawLanes, highway, flat] = r;
  if (EXCLUDED.test(rawName || '')) return;
  const points = [];
  for (let i = 0; i + 1 < flat.length; i += 2) points.push(toDest(flat[i], flat[i + 1]));
  const pieces = clipPolyline(points);
  const en = englishName(rawName);
  const zh = chineseName(rawName, en);
  const lanes = Math.max(1, Math.min(6, Math.round(+rawLanes) || 1));
  const w = carriagewayWidth(rawWidth, lanes, highway);
  const oneway = dir !== 'TW';
  const perWay = oneway ? lanes : Math.max(1, Math.ceil(lanes / 2));
  pieces.forEach((piece, part) => {
    const pts = piece.flatMap((p) => [round(p.x), round(p.z)]);
    let len = 0;
    for (let i = 0; i + 1 < piece.length; i++) len += Math.hypot(piece[i + 1].x - piece[i].x, piece[i + 1].z - piece[i].z);
    if (len < 2) return;
    roads.push({
      id: `cwb-r${sourceIndex}-${part}`,
      zh,
      en,
      cls: roadClass(rawName, highway),
      w,
      lanes: perWay,
      ...(oneway ? {} : { lanesForward: Math.max(1, Math.ceil(lanes / 2)), lanesBackward: Math.max(1, Math.floor(lanes / 2)) }),
      oneway,
      sidewalk: w >= 10 ? 2.8 : w >= 6 ? 2.2 : 1.8,
      source: 'landsd-osm',
      pts
    });
  });
});

const buildings = [];
GEO.blocks.forEach((b, sourceIndex) => {
  const [sourceRing, sourceHoles, , , , , height, base, name] = b;
  if (!Array.isArray(sourceRing) || sourceRing.length < 6) return;
  if (!(height >= 2.5 && height <= 500 && Number.isFinite(base))) return;
  const centreSource = ringCentre(sourceRing);
  const centre = toDest(centreSource.x, centreSource.z);
  if (centre.x < BOUNDS.minX || centre.x > BOUNDS.maxX || centre.z < BOUNDS.minZ || centre.z > BOUNDS.maxZ) return;
  const convertRing = (ring) => {
    const out = [];
    for (let i = 0; i + 1 < ring.length; i += 2) {
      const p = toDest(ring[i], ring[i + 1]);
      out.push(round(p.x), round(p.z));
    }
    return out;
  };
  const ring = convertRing(sourceRing);
  if (ringArea(ring) < 12) return;
  const holes = (sourceHoles || []).map(convertRing).filter((hole) => hole.length >= 6);
  buildings.push({
    id: `cwb-b${sourceIndex}`,
    ring,
    ...(holes.length ? { holes } : {}),
    h: round(height),
    base: round(base - GROUND_HKPD + 0.15, 2),
    name: name || '',
    tower: base + height >= 120 ? 1 : 0,
    source: 'landsd-building'
  });
});

const payload = {
  version: 1,
  district: 'causeway-bay',
  bounds: BOUNDS,
  replacementMargin: 36,
  groundHKPD: GROUND_HKPD,
  source: {
    repository: SOURCE_URL,
    commit: SOURCE_COMMIT,
    roads: 'Lands Department Road Centreline via CSDI; class/lanes/width from OpenStreetMap contributors (ODbL)',
    buildings: 'Lands Department Building footprints, BaseHeight and TopHeight via CSDI / DATA.GOV.HK',
    note: 'Lane markings are derived, not Traffic Aids survey geometry. No photogrammetry is embedded in this pack.'
  },
  roads,
  buildings
};

const banner = `// GENERATED by tools/hk/build-cwb-pilot.mjs — do not edit by hand.\n` +
  `// Source: ${SOURCE_URL} commit ${SOURCE_COMMIT}\n` +
  `// Lands Department data via CSDI / DATA.GOV.HK; OSM contributors (ODbL).\n`;
writeFileSync(opts.out, `${banner}export const CWB = ${JSON.stringify(payload)};\n`);
console.log(`Wrote ${path.relative(ROOT, opts.out)}: ${roads.length} road pieces, ${buildings.length} building parts`);
console.log(`Bounds ${JSON.stringify(BOUNDS)}; ground ${GROUND_HKPD} m HKPD`);
