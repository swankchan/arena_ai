// Simplified CWB gameplay collision: a player circle against the real 2D
// footprint, never against the optional photogrammetry triangles. A single
// min-area rectangle around a concave podium can otherwise close a real road.

export function pointInFlatRing(x, z, ring) {
  let inside = false;
  for (let i = 0, j = ring.length - 2; i < ring.length; j = i, i += 2) {
    const xi = ring[i];
    const zi = ring[i + 1];
    const xj = ring[j];
    const zj = ring[j + 1];
    if ((zi > z) !== (zj > z) && x < (xj - xi) * (z - zi) / (zj - zi) + xi) inside = !inside;
  }
  return inside;
}

function closestOnRing(x, z, ring) {
  let best = null;
  for (let i = 0, j = ring.length - 2; i < ring.length; j = i, i += 2) {
    const ax = ring[j];
    const az = ring[j + 1];
    const dx = ring[i] - ax;
    const dz = ring[i + 1] - az;
    const length2 = dx * dx + dz * dz;
    if (length2 < 1e-12) continue;
    const t = Math.max(0, Math.min(1, ((x - ax) * dx + (z - az) * dz) / length2));
    const px = ax + dx * t;
    const pz = az + dz * t;
    const d2 = (x - px) ** 2 + (z - pz) ** 2;
    if (!best || d2 < best.d2) best = { x: px, z: pz, d2, dx, dz };
  }
  return best;
}

function signedArea(ring) {
  let area = 0;
  for (let i = 0, j = ring.length - 2; i < ring.length; j = i, i += 2) {
    area += ring[j] * ring[i + 1] - ring[i] * ring[j + 1];
  }
  return area / 2;
}

function boundaryNormal(edge, ring, hole) {
  const length = Math.hypot(edge.dx, edge.dz) || 1;
  // In an x/z plane a positive-area ring has its interior on the left.
  // Outer empty space is therefore right; hole empty space is left.
  const left = hole ? 1 : -1;
  const sign = signedArea(ring) >= 0 ? left : -left;
  return { x: -edge.dz / length * sign, z: edge.dx / length * sign };
}

/**
 * Mutates {x, z} only when the circle touches solid footprint geometry.
 * Returns whether a collision was resolved. Courtyard holes remain open.
 */
export function resolveCircleAgainstFootprint(point, collider, radius) {
  const outer = collider.ring;
  if (!Array.isArray(outer) || outer.length < 6) return false;
  const holes = collider.holes || [];
  const insideOuter = pointInFlatRing(point.x, point.z, outer);
  const containingHole = insideOuter ? holes.find((ring) => pointInFlatRing(point.x, point.z, ring)) : null;
  const insideSolid = insideOuter && !containingHole;
  const rings = insideSolid ? [outer, ...holes] : [containingHole || outer];
  let nearest = null;
  let nearestRing = null;
  let nearestHole = false;
  for (const ring of rings) {
    const candidate = closestOnRing(point.x, point.z, ring);
    if (candidate && (!nearest || candidate.d2 < nearest.d2)) {
      nearest = candidate;
      nearestRing = ring;
      nearestHole = ring !== outer;
    }
  }
  if (!nearest || (!insideSolid && nearest.d2 >= radius * radius)) return false;

  const dx = point.x - nearest.x;
  const dz = point.z - nearest.z;
  const distance = Math.sqrt(nearest.d2);
  if (distance > 1e-8) {
    if (insideSolid) {
      const push = distance + radius + 1e-6;
      point.x -= dx / distance * push;
      point.z -= dz / distance * push;
    } else {
      const push = radius - distance + 1e-6;
      point.x += dx / distance * push;
      point.z += dz / distance * push;
    }
  } else {
    const normal = boundaryNormal(nearest, nearestRing, nearestHole);
    point.x += normal.x * (radius + 1e-6);
    point.z += normal.z * (radius + 1e-6);
  }
  return true;
}

/**
 * AI traffic uses only lanes whose full sampled centreline clears the real
 * ground-level footprints by the player/car radius. This is deliberately a
 * lane-level filter: one unsafe outer lane must not close the whole street.
 */
export function filterFootprintClearanceLanes(lanes, colliders, poseAt, radius = 1.35, step = 4) {
  const kept = [];
  const dropped = [];
  for (const lane of lanes) {
    // Seed corridors remain governed by their existing OBB traffic tests. This
    // scoped filter must not close a long seed street because of one pilot-edge sample.
    if (lane.road.source !== 'landsd-osm') {
      kept.push(lane);
      continue;
    }
    let blockedAt = null;
    const samples = [];
    for (let s = 0; s <= lane.len; s += step) samples.push(s);
    if (!samples.length || samples[samples.length - 1] < lane.len) samples.push(lane.len);
    for (const s of samples) {
      const pose = poseAt(lane, s);
      const point = { x: pose.x, z: pose.z };
      for (const collider of colliders) {
        if (point.x < collider.minX - radius || point.x > collider.maxX + radius ||
            point.z < collider.minZ - radius || point.z > collider.maxZ + radius) continue;
        if ((Number.isFinite(collider.minY) && collider.minY > 1.85) ||
            (Number.isFinite(collider.maxY) && collider.maxY < 0.15)) continue;
        if (resolveCircleAgainstFootprint(point, collider, radius)) {
          blockedAt = s;
          break;
        }
      }
      if (blockedAt !== null) break;
    }
    if (blockedAt === null) kept.push(lane);
    else dropped.push({ lane, s: blockedAt });
  }
  return { lanes: kept, dropped };
}
