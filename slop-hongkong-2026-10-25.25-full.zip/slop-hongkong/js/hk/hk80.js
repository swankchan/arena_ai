// HK1980 Grid (EPSG:2326) → HK80 geographic → WGS84 → application world.
// The inverse Transverse Mercator constants and small-area HK80/WGS84 shift
// follow the LandsD conversion notes used by keithligh/slop-hongkong.
// No runtime dependency, so the downloader and browser share identical maths.

const A_HK = 6378388;
const E2_HK = 6.722670022e-3;
const E4_HK = E2_HK * E2_HK;
const GRID_N0 = 819069.8;
const GRID_E0 = 836694.05;
const PHI0 = (22 + 18 / 60 + 43.68 / 3600) * Math.PI / 180;
const LAM0 = (114 + 10 / 60 + 42.8 / 3600) * Math.PI / 180;
const M0 = 2468395.728;
const A0 = 1 - E2_HK / 4 - 3 * E4_HK / 64;
const A2 = 3 / 8 * (E2_HK + E4_HK / 4);
const A4 = 15 * E4_HK / 256;

export const APPLICATION_FRAME = Object.freeze({
  originLat: 22.282,
  originLon: 114.158,
  mPerDegLat: 110734.08,
  mPerDegLon: 103056.75
});

function meridian(phi) {
  return A_HK * (A0 * phi - A2 * Math.sin(2 * phi) + A4 * Math.sin(4 * phi));
}

export function hk80GridToHk80Geog(easting, northing) {
  const target = M0 + northing - GRID_N0;
  let phi = PHI0;
  for (let i = 0; i < 30; i++) {
    const previous = phi;
    phi += (target - meridian(phi)) / (A_HK * (1 - E2_HK) / (1 - E2_HK * Math.sin(phi) ** 2) ** 1.5);
    if (Math.abs(phi - previous) < 1e-13) break;
  }
  const s = Math.sin(phi);
  const c = Math.cos(phi);
  const t = Math.tan(phi);
  const nu = A_HK / Math.sqrt(1 - E2_HK * s * s);
  const rho = A_HK * (1 - E2_HK) / (1 - E2_HK * s * s) ** 1.5;
  const psi = nu / rho;
  const dE = easting - GRID_E0;
  const x = dE / nu;
  const lat = phi - t / rho * dE * dE / (2 * nu);
  const lon = LAM0 + x / c - x ** 3 / (6 * c) * (psi + 2 * t * t);
  return { lat: lat * 180 / Math.PI, lon: lon * 180 / Math.PI };
}

export function hk80GridToWgs84(easting, northing) {
  const hk = hk80GridToHk80Geog(easting, northing);
  return { lat: hk.lat - 5.5 / 3600, lon: hk.lon + 8.8 / 3600 };
}

export function hk80ToWorld(easting, northing, hkpd = 0, {
  frame = APPLICATION_FRAME,
  groundHKPD = 0,
  groundY = 0.15
} = {}) {
  const { lat, lon } = hk80GridToWgs84(easting, northing);
  return {
    x: (lon - frame.originLon) * frame.mPerDegLon,
    y: hkpd - groundHKPD + groundY,
    z: (frame.originLat - lat) * frame.mPerDegLat
  };
}

function localMatrix(node) {
  if (node.matrix?.length === 16) return node.matrix;
  const t = node.translation || [0, 0, 0];
  return [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, t[0], t[1], t[2], 1];
}

function multiplyMatrix(a, b) {
  const out = new Array(16);
  for (let c = 0; c < 4; c++) {
    for (let r = 0; r < 4; r++) {
      out[c * 4 + r] = a[r] * b[c * 4] + a[4 + r] * b[c * 4 + 1]
        + a[8 + r] * b[c * 4 + 2] + a[12 + r] * b[c * 4 + 3];
    }
  }
  return out;
}

function applyMatrix(matrix, x, y, z) {
  return [
    matrix[0] * x + matrix[4] * y + matrix[8] * z + matrix[12],
    matrix[1] * x + matrix[5] * y + matrix[9] * z + matrix[13],
    matrix[2] * x + matrix[6] * y + matrix[10] * z + matrix[14]
  ];
}

/** Read model bounds from glTF accessors; geometry buffers are not needed. */
export function boundsFromGltf(doc, options = {}) {
  const nodes = doc.nodes || [];
  const worlds = new Array(nodes.length);
  const worldOf = (index, parent) => {
    if (worlds[index]) return worlds[index];
    const local = localMatrix(nodes[index] || {});
    const matrix = parent ? multiplyMatrix(parent, local) : local.slice();
    worlds[index] = matrix;
    for (const child of nodes[index]?.children || []) worldOf(child, matrix);
    return matrix;
  };
  const scene = (doc.scenes || [])[doc.scene || 0] || { nodes: [] };
  for (const index of scene.nodes || []) worldOf(index, null);

  const box = {
    minX: Infinity, maxX: -Infinity, minZ: -Infinity, maxZ: Infinity,
    minY: Infinity, maxY: -Infinity, minH: Infinity, maxH: -Infinity
  };
  // Written explicitly below to avoid accidentally swapping Z bounds.
  box.minZ = Infinity;
  box.maxZ = -Infinity;
  let any = false;
  nodes.forEach((node, index) => {
    if (node.mesh == null) return;
    const mesh = (doc.meshes || [])[node.mesh];
    const matrix = worlds[index] || localMatrix(node);
    for (const primitive of mesh?.primitives || []) {
      const accessor = (doc.accessors || [])[primitive.attributes?.POSITION];
      if (!accessor?.min || !accessor?.max) continue;
      const [x0, y0, z0] = accessor.min;
      const [x1, y1, z1] = accessor.max;
      for (const x of [x0, x1]) for (const y of [y0, y1]) for (const z of [z0, z1]) {
        const placed = applyMatrix(matrix, x, y, z);
        const world = hk80ToWorld(placed[0], -placed[2], placed[1], options);
        box.minX = Math.min(box.minX, world.x);
        box.maxX = Math.max(box.maxX, world.x);
        box.minZ = Math.min(box.minZ, world.z);
        box.maxZ = Math.max(box.maxZ, world.z);
        box.minY = Math.min(box.minY, world.y);
        box.maxY = Math.max(box.maxY, world.y);
        box.minH = Math.min(box.minH, placed[1]);
        box.maxH = Math.max(box.maxH, placed[1]);
        any = true;
      }
    }
  });
  if (!any) throw new Error('glTF has no POSITION accessor bounds');
  return {
    name: nodes.find((node) => node.name)?.name || '',
    ...box,
    span: Math.max(box.maxX - box.minX, box.maxZ - box.minZ)
  };
}

export function isBuildingGltf(filePath) {
  const normal = String(filePath || '').replace(/\\/g, '/');
  const file = normal.split('/').pop() || '';
  if (!file.toLowerCase().endsWith('.gltf')) return false;
  const upper = normal.toUpperCase();
  return upper.includes('/BUILDING/') || upper.startsWith('BUILDING/') || file.toUpperCase().startsWith('BUILDING_');
}
