import * as THREE from 'three/webgpu';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { createCurtainWallMaterial, createPreWarBuildingMaterial } from '../tsl-materials.js';
import { minAreaRect } from './csdi.js';

// Causeway Bay pilot: actual LandsD footprints and vertical building parts.
// Visual meshes, traffic centrelines and simplified collision rectangles remain
// separate. No photogrammetry is claimed by this module.

function pairs(flat) {
  const out = [];
  for (let i = 0; i + 1 < flat.length; i += 2) out.push({ x: flat[i], z: flat[i + 1] });
  return out;
}

function shapeFromBuilding(building) {
  const shape = new THREE.Shape();
  const addRing = (Target, flat) => {
    const ring = new Target();
    ring.moveTo(flat[0], -flat[1]);
    for (let i = 2; i + 1 < flat.length; i += 2) ring.lineTo(flat[i], -flat[i + 1]);
    ring.closePath();
    return ring;
  };
  const outer = addRing(THREE.Shape, building.ring);
  outer.holes = (building.holes || []).map((hole) => addRing(THREE.Path, hole));
  return outer;
}

// ExtrudeGeometry is non-indexed and has cap/side groups. Split those groups so
// the facade shader never paints a window grid over a roof.
function splitExtrudeGroups(geometry) {
  const caps = [];
  const sides = [];
  for (const group of geometry.groups) {
    const part = new THREE.BufferGeometry();
    for (const [name, attribute] of Object.entries(geometry.attributes)) {
      const array = attribute.array.slice(group.start * attribute.itemSize, (group.start + group.count) * attribute.itemSize);
      part.setAttribute(name, new THREE.BufferAttribute(array, attribute.itemSize, attribute.normalized));
    }
    part.computeBoundingBox();
    part.computeBoundingSphere();
    (group.materialIndex === 0 ? caps : sides).push(part);
  }
  geometry.dispose();
  return { caps, sides };
}

function mergedMesh(geometries, material, name) {
  if (!geometries.length) return null;
  const geometry = geometries.length === 1 ? geometries[0] : mergeGeometries(geometries, false);
  if (!geometry) throw new Error(`${name}: could not merge building geometry`);
  const mesh = new THREE.Mesh(geometry, material);
  mesh.name = name;
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  return mesh;
}

/**
 * Build only the visual subset. Collision is deliberately computed separately
 * from the complete list, so a failed optional glTF cannot remove collision.
 */
export function buildCausewayBayBuildings(group, list) {
  const capGeometries = [];
  const midRiseGeometries = [];
  const towerGeometries = [];
  for (const building of list) {
    if (!(building.h > 0) || building.ring?.length < 6) continue;
    const geometry = new THREE.ExtrudeGeometry(shapeFromBuilding(building), {
      depth: building.h,
      steps: 1,
      bevelEnabled: false,
      curveSegments: 1
    });
    geometry.rotateX(-Math.PI / 2);
    geometry.translate(0, building.base, 0);
    const { caps, sides } = splitExtrudeGroups(geometry);
    capGeometries.push(...caps);
    (building.tower ? towerGeometries : midRiseGeometries).push(...sides);
  }

  const roof = new THREE.MeshStandardNodeMaterial({ color: 0x666965, roughness: 0.93, metalness: 0.02 });
  const curtain = createCurtainWallMaterial({
    boxLocal: false,
    glassTint: 0x243d4a,
    frameTint: 0x3e4648,
    windowWidth: 2.6,
    floorHeight: 3.6,
    litProbability: 0.38,
    warmth: 0.52,
    reflectivity: 0.55,
    seed: 23
  });
  const masonry = createPreWarBuildingMaterial({
    boxLocal: false,
    stoneColor: 0xaaa394,
    trimColor: 0xd0c8b8,
    windowWidth: 2.4,
    floorHeight: 3.2,
    litProbability: 0.32,
    warmth: 0.68,
    cornerPier: 0.55,
    seed: 29
  });

  const meshes = [
    mergedMesh(capGeometries, roof, 'CausewayBayRealRoofs'),
    mergedMesh(midRiseGeometries, masonry, 'CausewayBayRealMidRise'),
    mergedMesh(towerGeometries, curtain, 'CausewayBayRealTowers')
  ].filter(Boolean);
  group.add(...meshes);
  return { meshes, count: list.length };
}

/** One conservative OBB per real building part, used only for gameplay. */
export function causewayBayBuildingColliders(list) {
  const colliders = [];
  for (const building of list) {
    const ring = pairs(building.ring || []);
    const rect = minAreaRect(ring);
    if (!rect) continue;
    const c = Math.abs(Math.cos(rect.rot));
    const s = Math.abs(Math.sin(rect.rot));
    const hx = (rect.w * c + rect.d * s) / 2;
    const hz = (rect.w * s + rect.d * c) / 2;
    colliders.push({
      minX: rect.x - hx,
      maxX: rect.x + hx,
      minZ: rect.z - hz,
      maxZ: rect.z + hz,
      minY: building.base,
      maxY: building.base + building.h,
      x: rect.x,
      z: rect.z,
      rot: rect.rot,
      hw: rect.w / 2,
      hd: rect.d / 2,
      kind: 'building',
      source: 'landsd-building',
      id: building.id,
      // Gameplay uses the simple 2D polygon (plus holes), not this conservative
      // rectangle and not the optional photo mesh. The OBB remains as broadphase
      // metadata for diagnostics and older callers.
      ring: building.ring,
      holes: building.holes || []
    });
  }
  return colliders;
}
