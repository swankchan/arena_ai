import { GEO } from '../hk-geodata.js';
import { COAST as COAST_DATA } from '../hk-coastline.js';
import { CWB } from './cwb-geodata.js';
import { HK_ROAD_PACK } from './full-road-geodata.js';

// js/hk/config.js
// 香港世界觀（Hong Kong world config）— 由 js/hk-geodata.js 推導出來的執行期世界。
//
// 與 city-config.js（紐約）的分別：
//   · 沒有 numbered streets / avenue x：香港用「走廊 corridor」＝ 一條有名有姓、有自己方位角的道路折線；
//   · 真北朝上（x = 東, z = 南, north = −z），不需要曼哈頓的 29.02° 網格旋轉；
//   · 靠左行駛（left-hand traffic）：車道是中心線「向左」的偏移，全部由 laneLateral() 一處定義；
//   · 街道查詢以最近走廊 + 沿線距離（chainage）回答，取代 streetZ(n)/avenueX(id)。

const pairs = (flat) => {
  const out = [];
  for (let i = 0; i + 1 < flat.length; i += 2) out.push({ x: flat[i], z: flat[i + 1] });
  return out;
};
const closedRing = (flat) => {
  const pts = pairs(flat);
  if (pts.length && (pts[0].x !== pts[pts.length - 1].x || pts[0].z !== pts[pts.length - 1].z)) pts.push(pts[0]);
  return pts;
};

export const FRAME = GEO.frame;
export const WATER_LEVEL = GEO.frame.waterLevel;
export const ORIGIN = { lat: GEO.frame.originLat, lon: GEO.frame.originLon };
export const M_PER_DEG_LAT = GEO.frame.mPerDegLat;
export const M_PER_DEG_LON = GEO.frame.mPerDegLon;

/** 香港法例：靠左行駛。行車方向的左法線。 */
export const laneLateral = (dx, dz) => ({ x: dz + 0, z: 0 - dx });
/** 第 i 條行車線（由中心線數起）中心向左的距離（m）。 */
export const laneCentreOffset = (i, laneWidth) => (i + 0.5) * laneWidth;

export const LANE_WIDTH = 3.4;
export const SIDEWALK = 3.5;
export const KERB_HEIGHT = 0.15;

// --- 走廊（corridors）----------------------------------------------------------------------------------
function lengthOf(pts) {
  let len = 0;
  const cum = [0];
  for (let i = 1; i < pts.length; i++) {
    len += Math.hypot(pts[i].x - pts[i - 1].x, pts[i].z - pts[i - 1].z);
    cum.push(len);
  }
  return { len, cum };
}

export const CWB_BOUNDS = Object.freeze({ ...CWB.bounds });
export const CWB_ROADS = CWB.roads;
export const CWB_BUILDINGS = CWB.buildings;
export const CWB_SOURCE = CWB.source;
export const CWB_GROUND_HKPD = CWB.groundHKPD;

/** 銅鑼灣試點內改用真實資料；外圍種子內容向內多退一段，避免兩套樓重疊。 */
export function inCausewayBayReplacement(x, z, margin = CWB.replacementMargin) {
  return x >= CWB.bounds.minX - margin && x <= CWB.bounds.maxX + margin
    && z >= CWB.bounds.minZ - margin && z <= CWB.bounds.maxZ + margin;
}

/** 舊 Gloucester Road 只保留試點以西；舊 Yee Wo Street 則整條由真實路段取代。 */
function clipSeedRoadWest(road, maxX) {
  const source = pairs(road.pts);
  const out = [];
  for (let i = 0; i < source.length; i++) {
    const p = source[i];
    if (p.x <= maxX) {
      out.push(p);
      continue;
    }
    const prev = source[i - 1];
    if (prev && prev.x < maxX) {
      const t = (maxX - prev.x) / (p.x - prev.x);
      out.push({ x: maxX, z: prev.z + (p.z - prev.z) * t });
    }
    break;
  }
  if (out.length < 2) return null;
  return { ...road, pts: out.flatMap((p) => [p.x, p.z]) };
}

const SEED_ROADS = GEO.roads
  .filter((road) => road.en !== 'Yee Wo Street')
  .map((road) => road.en === 'Gloucester Road' ? clipSeedRoadWest(road, CWB.bounds.minX) : road)
  .filter(Boolean);

// The existing detailed buildings/pedestrians cover this core. Full roads and
// paint extend far beyond it; dense furniture remains core-only for GPU budget.
export const DETAIL_BOUNDS = (() => {
  const bounds = { minX: Infinity, maxX: -Infinity, minZ: Infinity, maxZ: -Infinity };
  for (const road of SEED_ROADS) for (const p of pairs(road.pts)) {
    bounds.minX = Math.min(bounds.minX, p.x - 120);
    bounds.maxX = Math.max(bounds.maxX, p.x + 120);
    bounds.minZ = Math.min(bounds.minZ, p.z - 120);
    bounds.maxZ = Math.max(bounds.maxZ, p.z + 120);
  }
  return Object.freeze(bounds);
})();
export function roadInDetail(road) {
  return road.pts.some((p) => p.x >= DETAIL_BOUNDS.minX && p.x <= DETAIL_BOUNDS.maxX
    && p.z >= DETAIL_BOUNDS.minZ && p.z <= DETAIL_BOUNDS.maxZ);
}

// Complete at-grade graph from the same LandsD/OSM source family as CWB. The
// source graph deliberately has no tunnel/bridge/ramp links, so nothing elevated
// is falsely flattened. These links are the visual/query network; the older
// local AI still uses TRAFFIC_ROADS until its junction router is replaced.
const GRAPH_ARMS = new Map();
HK_ROAD_PACK.links.forEach((link, index) => {
  for (const node of [link[0], link[1]]) {
    if (!GRAPH_ARMS.has(node)) GRAPH_ARMS.set(node, []);
    GRAPH_ARMS.get(node).push(index);
  }
});
function graphJunction(node) {
  const arms = GRAPH_ARMS.get(node) || [];
  return arms.length >= 3 || new Set(arms.map((index) => HK_ROAD_PACK.links[index][2])).size >= 2;
}
const FULL_ROADS = HK_ROAD_PACK.links.map((link, index) => {
  const [a, b, nameIndex, w, lanes, dir, inner] = link;
  let flat = [HK_ROAD_PACK.nodes[a * 2], HK_ROAD_PACK.nodes[a * 2 + 1], ...inner,
    HK_ROAD_PACK.nodes[b * 2], HK_ROAD_PACK.nodes[b * 2 + 1]];
  if (dir < 0) flat = pairs(flat).reverse().flatMap((p) => [p.x, p.z]);
  const [zh, en] = HK_ROAD_PACK.names[nameIndex];
  const oneway = dir !== 0;
  const count = Math.max(1, Math.min(12, Math.round(lanes) || 1));
  const junctionA = graphJunction(a);
  const junctionB = graphJunction(b);
  return {
    id: `hk-g${index}`, a, b, dir, zh, en,
    cls: w >= 12 ? 'trunk' : w >= 8 ? 'primary' : 'secondary',
    w, lanes: oneway ? count : Math.max(1, Math.ceil(count / 2)),
    ...(oneway ? {} : { lanesForward: Math.max(1, Math.ceil(count / 2)), lanesBackward: Math.max(1, Math.floor(count / 2)) }),
    oneway, sidewalk: w >= 10 ? 2.8 : w >= 6 ? 2.2 : 1.8,
    source: 'landsd-osm-graph', traffic: false,
    junctionStart: dir < 0 ? junctionB : junctionA,
    junctionEnd: dir < 0 ? junctionA : junctionB,
    pts: flat
  };
});

function normaliseRoad(r) {
  const pts = pairs(r.pts);
  const { len, cum } = lengthOf(pts);
  // Short CWB pieces remain visible but do not enter the old loop-per-corridor AI.
  const traffic = r.source === 'landsd-osm' ? len >= 30 && r.en !== 'Unnamed road' : r.traffic !== false;
  return { ...r, pts, len, cum, traffic, lanesPerWay: Math.max(1, Math.min(12, Math.round(r.lanes))) };
}

export const ROADS = FULL_ROADS.map(normaliseRoad);
export const TRAFFIC_ROADS = [...SEED_ROADS, ...CWB.roads].map(normaliseRoad);
export const FULL_ROAD_STATS = Object.freeze({
  nodes: HK_ROAD_PACK.nodes.length / 2,
  links: HK_ROAD_PACK.links.length,
  names: HK_ROAD_PACK.names.length,
  bounds: HK_ROAD_PACK.bounds,
  source: HK_ROAD_PACK.source
});

/** 雙向路可以係 2+1 條線；種子路沒有分拆時維持兩個方向相同。 */
export function laneCountFor(road, dir = 1) {
  if (road.oneway) return road.lanesPerWay;
  const asymmetric = dir === 1 ? road.lanesForward : road.lanesBackward;
  return Math.max(1, Math.round(asymmetric ?? road.lanesPerWay));
}

/** 車線闊度受該邊實際行車道限制，唔再一律 3.4 m 伸出馬路外。 */
export function laneWidthFor(road, dir = 1, count = laneCountFor(road, dir)) {
  const available = road.oneway ? road.w : road.w / 2;
  return Math.min(LANE_WIDTH, available / Math.max(1, count));
}

/**
 * 車線中心在行車方向左法線上的距離。
 * 雙向路由中心向外數；單程路則把全部車線置中於整條行車道，最後一條係左側路邊線。
 */
export function laneOffsetFor(road, dir, lane) {
  const count = laneCountFor(road, dir);
  const width = laneWidthFor(road, dir, count);
  const i = Math.max(0, Math.min(count - 1, lane));
  if (!road.oneway) return (i + 0.5) * width;
  return -width * count / 2 + (i + 0.5) * width;
}

/** 沿走廊的位置：[x, z] at chainage s (m), plus the unit direction there. */
export function alongRoad(road, s) {
  const t = Math.max(0, Math.min(road.len, s));
  let i = 1;
  while (i < road.cum.length - 1 && road.cum[i] < t) i++;
  const a = road.pts[i - 1];
  const b = road.pts[i];
  const segLen = Math.max(1e-6, road.cum[i] - road.cum[i - 1]);
  const f = (t - road.cum[i - 1]) / segLen;
  return { x: a.x + (b.x - a.x) * f, z: a.z + (b.z - a.z) * f, dx: (b.x - a.x) / segLen, dz: (b.z - a.z) / segLen };
}

/** 走廊折線平移 offset（正值 = 行車方向的左側），附上每個頂點的行車方向。 */
export function offsetPolyline(pts, offset) {
  const out = [];
  for (let i = 0; i < pts.length; i++) {
    const a = pts[Math.max(0, i - 1)];
    const b = pts[Math.min(pts.length - 1, i + 1)];
    let dx = b.x - a.x;
    let dz = b.z - a.z;
    let l = Math.hypot(dx, dz);
    if (l < 1e-9) {
      // A rounded U-turn can make the central-difference neighbours coincide
      // even though the adjacent segments are valid. Fall back to a real edge.
      let found = false;
      for (let j = i + 1; j < pts.length; j++) {
        if (Math.hypot(pts[j].x - pts[i].x, pts[j].z - pts[i].z) > 1e-9) {
          dx = pts[j].x - pts[i].x;
          dz = pts[j].z - pts[i].z;
          found = true;
          break;
        }
      }
      for (let j = i - 1; !found && j >= 0; j--) {
        if (Math.hypot(pts[i].x - pts[j].x, pts[i].z - pts[j].z) > 1e-9) {
          dx = pts[i].x - pts[j].x;
          dz = pts[i].z - pts[j].z;
          found = true;
          break;
        }
      }
      if (!found) { dx = 1; dz = 0; }
      l = Math.hypot(dx, dz);
    }
    dx /= l;
    dz /= l;
    const left = laneLateral(dx, dz);
    out.push({ x: pts[i].x + left.x * offset, z: pts[i].z + left.z * offset, dx, dz });
  }
  return out;
}

/** 走廊 → 車道：雙向走廊兩組（各自靠左），單程路一組；短碎段只做視覺，不進舊 AI。 */
export function buildLanes(roads = TRAFFIC_ROADS) {
  const lanes = [];
  for (const road of roads) {
    if (road.traffic === false || !(road.len > 20)) continue;
    const dirs = road.oneway ? [1] : [1, -1];
    for (const dir of dirs) {
      const base = dir === 1 ? road.pts : [...road.pts].reverse().map((p) => ({ x: p.x, z: p.z }));
      const count = laneCountFor(road, dir);
      const width = laneWidthFor(road, dir, count);
      for (let i = 0; i < count; i++) {
        const offset = laneOffsetFor(road, dir, i);
        const pts = offsetPolyline(base, offset);
        const cum = [0];
        for (let k = 1; k < pts.length; k++) cum.push(cum[k - 1] + Math.hypot(pts[k].x - pts[k - 1].x, pts[k].z - pts[k - 1].z));
        lanes.push({ road, dir, lane: i, laneWidth: width, offset, isKerbLane: i === count - 1, pts, cum, len: cum[cum.length - 1] });
      }
    }
  }
  return lanes;
}

/** 車道上的位置與朝向（s = 沿線距離，米） */
export function poseAt(lane, s) {
  const t = Math.max(0, Math.min(lane.len, s));
  let i = 1;
  while (i < lane.cum.length - 1 && lane.cum[i] < t) i++;
  const a = lane.pts[i - 1];
  const b = lane.pts[i];
  const segLen = Math.max(1e-6, lane.cum[i] - lane.cum[i - 1]);
  const f = (t - lane.cum[i - 1]) / segLen;
  return {
    x: a.x + (b.x - a.x) * f,
    z: a.z + (b.z - a.z) * f,
    dx: b.dx,
    dz: b.dz,
    heading: Math.atan2(b.dx, b.dz)
  };
}

// --- 最近道路索引（100 m 網格）-------------------------------------------------------------------------
const CELL = 100;
const roadGrid = new Map();
const key = (ix, iz) => ix * 100003 + iz;
for (const road of ROADS) {
  for (let i = 0; i + 1 < road.pts.length; i++) {
    const a = road.pts[i];
    const b = road.pts[i + 1];
    for (let ix = Math.floor(Math.min(a.x, b.x) / CELL); ix <= Math.floor(Math.max(a.x, b.x) / CELL); ix++) {
      for (let iz = Math.floor(Math.min(a.z, b.z) / CELL); iz <= Math.floor(Math.max(a.z, b.z) / CELL); iz++) {
        const k = key(ix, iz);
        if (!roadGrid.has(k)) roadGrid.set(k, []);
        roadGrid.get(k).push({ road, ax: a.x, az: a.z, bx: b.x, bz: b.z });
      }
    }
  }
}

/** 最近的走廊段：{ road, dist, x, z, dx, dz } 或 null。 */
export function nearestRoad(x, z, radius = 400) {
  const reach = Math.ceil(radius / CELL);
  const ci = Math.floor(x / CELL);
  const cz = Math.floor(z / CELL);
  let best = null;
  for (let ix = ci - reach; ix <= ci + reach; ix++) {
    for (let iz = cz - reach; iz <= cz + reach; iz++) {
      const list = roadGrid.get(key(ix, iz));
      if (!list) continue;
      for (const s of list) {
        const dx = s.bx - s.ax;
        const dz = s.bz - s.az;
        const l2 = dx * dx + dz * dz || 1e-9;
        const t = Math.max(0, Math.min(1, ((x - s.ax) * dx + (z - s.az) * dz) / l2));
        const px = s.ax + t * dx;
        const pz = s.az + t * dz;
        const d = Math.hypot(px - x, pz - z);
        if (d > radius) continue;
        if (!best || d < best.dist) {
          const len = Math.sqrt(l2);
          best = { road: s.road, dist: d, x: px, z: pz, dx: dx / len, dz: dz / len };
        }
      }
    }
  }
  return best;
}

/** Candidate corridors near a footprint, without scanning all 16k graph links. */
export function roadsNear(x, z, radius) {
  const roads = new Set();
  const reach = Math.ceil(radius / CELL);
  const ci = Math.floor(x / CELL);
  const cz = Math.floor(z / CELL);
  for (let ix = ci - reach; ix <= ci + reach; ix++) {
    for (let iz = cz - reach; iz <= cz + reach; iz++) {
      for (const segment of roadGrid.get(key(ix, iz)) || []) roads.add(segment.road);
    }
  }
  return [...roads];
}

// --- 地區（districts）----------------------------------------------------------------------------------
export const DISTRICTS = GEO.districts.map((d) => ({ ...d, cx: (d.x0 + d.x1) / 2, cz: (d.z0 + d.z1) / 2 }));

export function districtAt(x, z) {
  for (const d of DISTRICTS) if (x >= d.x0 && x <= d.x1 && z >= d.z0 && z <= d.z1) return d;
  // outside the seed districts: nearest by centre, but say so honestly
  let best = DISTRICTS[0];
  let bd = Infinity;
  for (const d of DISTRICTS) {
    const dist = Math.hypot(x - d.cx, z - d.cz);
    if (dist < bd) { bd = dist; best = d; }
  }
  return best;
}

/** 香港式雙語位置說明：「中環 Central · 干諾道中 Connaught Road Central」 */
export function locationLabel(x, z) {
  const d = districtAt(x, z);
  const near = nearestRoad(x, z);
  if (!near) return `${d.zh} ${d.en}`;
  const head = near.dist > 260 ? `${d.zh} ${d.en}` : `${d.zh} ${d.en}`;
  return `${head} · ${near.road.zh} ${near.road.en}`;
}

// --- 地標、建築、土地 -----------------------------------------------------------------------------------
/**
 * 把地標「泊」到真正空得落的位置。
 *
 * 為什麼要做：地標座標直接來自 seed（真實經緯度），但我們的走廊是**加寬的近似線**，
 * 兩者一撞，就會出現「IFC / 交易廣場 / 大會堂 企正喺干諾道中馬路中間」這種情況
 * （實測 8 個地標壓住行車道，最近的中心距只有 4.8 m）。
 *
 * 做法：先算 support function（axis-aligned box 沿方向 n 的半寬 = |nx|·w/2 + |nz|·d/2），
 * 得到「距離最近車道邊界仲差幾多」。有重疊就做**螺旋搜尋**：由 4 m 起、每次 +4 m，
 * 16 個方向，揀第一個「完全離開所有行車道（含 margin）而且仍然在陸地上」的位置。
 * 咁樣一定收斂、位移最小，而且唔會好似逐段推開咁喺兩條路之間彈來彈去（曾經把大會堂推到 435 m 外）。
 */
function landmarkClearance(item, x, z, roads) {
  let worst = Infinity;
  const candidates = roads.length > 1000
    ? roadsNear(x, z, Math.hypot(item.w, item.d) / 2 + 36)
    : roads;
  for (const road of candidates) {
    const roadHalf = road.w / 2;
    for (let i = 1; i < road.pts.length; i++) {
      const a = road.pts[i - 1];
      const b = road.pts[i];
      const dx = b.x - a.x;
      const dz = b.z - a.z;
      const segLen2 = dx * dx + dz * dz || 1e-6;
      const t = Math.max(0, Math.min(1, ((x - a.x) * dx + (z - a.z) * dz) / segLen2));
      const px = a.x + dx * t;
      const pz = a.z + dz * t;
      let nx = x - px;
      let nz = z - pz;
      const dist = Math.hypot(nx, nz);
      if (dist > 1e-4) { nx /= dist; nz /= dist; } else { nx = 1; nz = 0; }
      const rot = item.rot || 0;
      const localNx = nx * Math.cos(rot) - nz * Math.sin(rot);
      const localNz = nx * Math.sin(rot) + nz * Math.cos(rot);
      const extent = Math.abs(localNx) * (item.w / 2) + Math.abs(localNz) * (item.d / 2);
      worst = Math.min(worst, dist - roadHalf - extent);
    }
  }
  return worst;
}

/** Signed clearance from full-graph carriageways; negative means overlap. */
export function fullRoadClearance(item, x = item.x, z = item.z) {
  return landmarkClearance(item, x, z, ROADS);
}

function pointInRing(x, z, ring) {
  let inside = false;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const xi = ring[i].x, zi = ring[i].z;
    const xj = ring[j].x, zj = ring[j].z;
    if ((zi > z) !== (zj > z) && x < ((xj - xi) * (z - zi)) / (zj - zi) + xi) inside = !inside;
  }
  return inside;
}

const LAND_RINGS = GEO.land.map((l) => pairs(l.ring));
function onLand(x, z) {
  return LAND_RINGS.some((ring) => pointInRing(x, z, ring));
}

function placeLandmarksOffRoad(list, roads, margin = 2.5) {
  const out = [];
  for (const item of list) {
    if (landmarkClearance(item, item.x, item.z, roads) >= margin && onLand(item.x, item.z)) {
      out.push({ ...item });
      continue;
    }
    let best = null;
    for (let radius = 4; radius <= 200 && !best; radius += 4) {
      for (let k = 0; k < 16; k++) {
        const angle = (k / 16) * Math.PI * 2;
        const x = item.x + Math.cos(angle) * radius;
        const z = item.z + Math.sin(angle) * radius;
        if (!onLand(x, z)) continue;
        if (landmarkClearance(item, x, z, roads) < margin) continue;
        best = { x, z, moved: radius };
        break;
      }
    }
    if (!best) {
      // 真係搵唔到位（例如被兩條主幹道夾死）：退而求其次，揀偏移最小、淨空最大的點
      let fallback = { x: item.x, z: item.z, clear: landmarkClearance(item, item.x, item.z, roads) };
      for (let radius = 4; radius <= 200; radius += 4) {
        for (let k = 0; k < 16; k++) {
          const angle = (k / 16) * Math.PI * 2;
          const x = item.x + Math.cos(angle) * radius;
          const z = item.z + Math.sin(angle) * radius;
          if (!onLand(x, z)) continue;
          const clear = landmarkClearance(item, x, z, roads);
          if (clear > fallback.clear + 0.5) fallback = { x, z, clear };
        }
        if (fallback.clear >= margin) break;
      }
      best = { x: fallback.x, z: fallback.z, moved: Math.hypot(fallback.x - item.x, fallback.z - item.z) };
    }
    out.push({ ...item, x: best.x, z: best.z, shiftedByRoad: Math.round(best.moved * 10) / 10 });
  }
  return out;
}

// Times Square 已由真實分層輪廓取代，唔再畫多一個種子盒。
export const LANDMARKS = placeLandmarksOffRoad(GEO.landmarks.filter((landmark) => landmark.id !== 'times-square'), ROADS);
/**
 * 真實海岸線（地政總署陸地邊界，見 js/hk-coastline.js）。
 * LAND 仍然是手繪的種子輪廓（3D 地面板塊沿用），而地圖用 COAST —— 因為地圖要「似香港」，
 * 手繪輪廓只會變成兩塊雲。所有 ring 都已 close，項目是 {x, z}。
 */
export const COAST = {
  /** 玩樂範圍的精細海岸線（中環—銅鑼灣、尖沙咀—旺角）。 */
  land: COAST_DATA.land.map(closedRing),
  /** 全港其餘陸地（新界、大嶼山、西貢、離島）—— 地圖縮細時用來認出香港。 */
  territory: COAST_DATA.territory.map(closedRing)
};
/** 全部陸地環（先畫 territory，再畫 land）。 */
export const COAST_ALL = [...COAST.territory, ...COAST.land];

/** 地圖／地理查詢用：這一點是否在真實海岸線的陸地上。 */
export function onCoastLand(x, z, rings = COAST_ALL) {
  return rings.some((ring) => pointInRing(x, z, ring));
}

/**
 * 樓宇。種子資料用「手繪陸地」生成，換成真實海岸線之後有 18 棟（1,349 棟之中）
 * 會落在海面（填海前的舊地界）。這裡直接剔除，唔會出現「海中心有樓」。
 */
const BUILT_ON_REAL_LAND = GEO.buildings.filter((b) => onCoastLand(b.x, b.z));
const SEED_OUTSIDE_CWB = BUILT_ON_REAL_LAND.filter((b) => !inCausewayBayReplacement(b.x, b.z));
// A road-first migration must not leave the old procedural street grid standing
// in the new carriageways. Keep non-conflicting seed buildings as interim massing;
// real LandsD footprints outside CWB are a separate later building tranche.
const SEED_CLEAR_OF_FULL_ROADS = SEED_OUTSIDE_CWB.filter((building) => fullRoadClearance(building) >= 2.2);
export const BUILDINGS = SEED_CLEAR_OF_FULL_ROADS;
export const BUILDING_STATS = {
  total: GEO.buildings.length,
  dropped: GEO.buildings.length - BUILT_ON_REAL_LAND.length,
  cwbSeedReplaced: BUILT_ON_REAL_LAND.length - SEED_OUTSIDE_CWB.length,
  fullRoadSeedConflicts: SEED_OUTSIDE_CWB.length - SEED_CLEAR_OF_FULL_ROADS.length,
  cwbRealParts: CWB_BUILDINGS.length,
  note: '海岸線剔除填海差異；CWB 用真實輪廓；舊 seed 樓如壓住全量真實道路會先剔除'
};
export const LAND = GEO.land.map((l) => ({ ...l, pts: closedRing(l.ring) }));


// 舊電車線在銅鑼灣仍是手繪。試點內先停在邊界，唔讓錯誤鋼軌穿入真實樓宇；
// 下輪應以正式電車軌資料接回，而不是把馬路中心線假裝成軌道。
const TRAM_WEST = clipSeedRoadWest({ pts: GEO.tram }, CWB.bounds.minX);
export const TRAM = pairs(TRAM_WEST.pts);
export const FERRY = { from: { x: GEO.ferry.from[0], z: GEO.ferry.from[1] }, to: { x: GEO.ferry.to[0], z: GEO.ferry.to[1] }, minutes: GEO.ferry.minutes };
export const TUNNELS = GEO.tunnels.map((t) => ({ ...t, pts: pairs(t.pts) }));

export const landmarkById = (id) => LANDMARKS.find((l) => l.id === id);

// --- 傳送點與出生點 -------------------------------------------------------------------------------------
/** 在指定走廊上取一個車道位置（t = 0..1 沿線比例）；傳送點永遠落在真實車道上。 */
function roadSpot(roadEn, t, lane = 1) {
  const candidates = ROADS.filter((r) => r.en === roadEn).sort((a, b) => b.len - a.len);
  const road = candidates[0] || ROADS.find((r) => r.en === roadEn) || ROADS[0];
  const p = alongRoad(road, road.len * Math.max(0, Math.min(1, t)));
  const left = laneLateral(p.dx, p.dz);
  const laneIndex = Math.min(lane, laneCountFor(road, 1) - 1);
  const off = laneOffsetFor(road, 1, laneIndex);
  return { x: p.x + left.x * off, z: p.z + left.z * off, heading: Math.atan2(p.dx, p.dz), road: road.en };
}

export const TELEPORTS = [
  { id: 'central', zh: '中環', en: 'Central', ...roadSpot('Connaught Road Central', 0.45), note: '皇后像廣場一帶 Statue Square' },
  { id: 'ifc', zh: '國金二期', en: 'Two IFC', ...roadSpot('Connaught Road Central', 0.63) },
  { id: 'admiralty', zh: '金鐘', en: 'Admiralty', ...roadSpot('Queensway', 0.5) },
  { id: 'wanchai', zh: '灣仔', en: 'Wan Chai', ...roadSpot('Hennessy Road', 0.25) },
  { id: 'causeway', zh: '銅鑼灣', en: 'Causeway Bay', ...roadSpot('Yee Wo Street', 0.5) },
  { id: 'tst', zh: '尖沙咀', en: 'Tsim Sha Tsui', ...roadSpot('Salisbury Road', 0.45) },
  { id: 'jordan', zh: '佐敦', en: 'Jordan', ...roadSpot('Jordan Road', 0.45) },
  { id: 'mongkok', zh: '旺角', en: 'Mong Kok', ...roadSpot('Nathan Road', 0.72) },
  { id: 'icc', zh: '環球貿易廣場', en: 'ICC', ...roadSpot('Austin Road', 0.12) }
];

// 出生：干諾道中・中環，向東（往金鐘）
export const SPAWN = roadSpot('Connaught Road Central', 0.45);

// --- 跟車模型（簡化 IDM；抽出來是為了可以單元測試）------------------------------------------------
/**
 * 目標速度：以「淨車距」決定。
 * gap 是兩車中心的沿線距離，所以要扣除前後車各自半車長，再扣靜止安全距。
 * @param {number} gap 與前車沿線中心距離（m），無前車傳 Infinity
 * @param {number} length 本車長（m）
 * @param {number} vmax 最高速（m/s）
 * @param {number} headway 每米淨距對應的速度（s/m），越大越保守
 * @param {number} leaderLength 前車長（m）；省略時沿用同車長情境，保持 API 相容
 */
export function followSpeed(gap, length, vmax, headway = 1.1, leaderLength = length) {
  if (!Number.isFinite(gap)) return vmax;
  const bodyClearance = gap - (length + leaderLength) / 2;
  const safe = Math.max(0, bodyClearance - 3);
  return Math.min(vmax, Math.max(0, safe / headway));
}

// --- 交通號誌（香港週期；黃燈後全紅緩衝，行人綠燈閃爍）--------------------------------------------------
export const SIGNAL = {
  cycle: 72,
  green: 30,
  amber: 3,
  allRed: 2,
  pedGreen: 24,
  pedFlash: 12
};

/** 幹道在 t 秒時的相位：'green' | 'amber' | 'red' */
export function signalPhase(t, isTrunk) {
  const offset = isTrunk ? 0 : SIGNAL.green + SIGNAL.amber + SIGNAL.allRed;
  const local = (((t + offset) % SIGNAL.cycle) + SIGNAL.cycle) % SIGNAL.cycle;
  if (local < SIGNAL.green) return 'green';
  if (local < SIGNAL.green + SIGNAL.amber) return 'amber';
  if (local < SIGNAL.green + SIGNAL.amber + SIGNAL.allRed) return 'red';
  return 'red';
}

/** 行人可否起步（綠燈人像；之後閃爍＝不准起步） */
export function walkPhase(t, isTrunk) {
  const offset = isTrunk ? 0 : SIGNAL.green + SIGNAL.amber + SIGNAL.allRed;
  const local = (((t + offset) % SIGNAL.cycle) + SIGNAL.cycle) % SIGNAL.cycle;
  return local < SIGNAL.pedGreen;
}

// --- 世界基本資料 ---------------------------------------------------------------------------------------
export const WORLD = {
  id: 'hong-kong',
  zh: '香港',
  en: 'Hong Kong',
  tagline: '香港 · 維多利亞港兩岸',
  speedUnit: 'km/h',
  driveSide: 'left',
  districts: DISTRICTS.length,
  buildings: BUILDINGS.length + CWB_BUILDINGS.length,
  roads: ROADS.length
};

/** 由 (x, z) 反推經緯度（地圖與外部工具用） */
export const toLatLon = (x, z) => [ORIGIN.lon + x / M_PER_DEG_LON, ORIGIN.lat - z / M_PER_DEG_LAT];
