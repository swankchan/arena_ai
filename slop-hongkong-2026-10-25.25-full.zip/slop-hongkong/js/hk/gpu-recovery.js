// GPU recovery helpers kept separate from the renderer so the navigation policy is testable.

/** Preserve the current world/model/debug options while forcing the WebGL2 backend. */
export function webglFallbackUrl(href) {
  const url = new URL(href);
  url.searchParams.set('webgl', '1');
  return url.href;
}

/** A deliberate renderer.dispose() must not trigger a reload; an unexpected reset must. */
export function isUnexpectedDeviceLoss(info) {
  return info?.reason !== 'destroyed';
}
