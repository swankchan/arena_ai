import assert from 'node:assert/strict';
import { existsSync } from 'node:fs';
import test from 'node:test';

// Exercise the real GLTFLoader path with a tiny embedded glTF. This is not an
// official LandsD asset or a GPU/browser rendering test; it proves that a
// successful model can replace only its overlapping fallback, while HTTP and
// parse failures leave the fallback plan intact.
const threePath = new URL('../node_modules/three/package.json', import.meta.url);
const skip = existsSync(threePath) ? false : 'three is not installed (npm install three@0.186.1 --no-save)';
const bounds = { minX: 2220, maxX: 3020, minZ: -380, maxZ: 520 };
const fallback = [{ id: 'b1', ring: [2660, 190, 2690, 190, 2690, 220, 2660, 220] }];

function syntheticGltfUrl() {
  // Two triangles in the official frame: X = HK1980 easting, Y = HKPD,
  // Z = -northing. The converted model lands inside the fallback above.
  const positions = new Float32Array([
    836990, 4, -815690, 837010, 4, -815690, 837010, 4, -815710,
    836990, 4, -815690, 837010, 4, -815710, 836990, 4, -815710
  ]);
  const bytes = Buffer.from(positions.buffer);
  const doc = {
    asset: { version: '2.0' },
    scene: 0,
    scenes: [{ nodes: [0] }],
    nodes: [{ mesh: 0 }],
    meshes: [{ primitives: [{ attributes: { POSITION: 0 } }] }],
    buffers: [{ byteLength: bytes.length, uri: `data:application/octet-stream;base64,${bytes.toString('base64')}` }],
    bufferViews: [{ buffer: 0, byteOffset: 0, byteLength: bytes.length }],
    accessors: [{
      bufferView: 0, componentType: 5126, count: positions.length / 3, type: 'VEC3',
      min: [836990, 4, -815710], max: [837010, 4, -815690]
    }]
  };
  return `data:model/gltf+json;base64,${Buffer.from(JSON.stringify(doc)).toString('base64')}`;
}

function manifestWith(file, category) {
  return {
    bounds,
    groundHKPD: 4,
    buildings: [{ file, sheet: 'synthetic', category, minX: 2660, maxX: 2690, minZ: 190, maxZ: 220, minY: 0.15, maxY: 4.15, span: 30 }]
  };
}

async function mountWith(manifest) {
  const THREE = await import('three/webgpu');
  const { mountCausewayBayModels } = await import('../js/hk/cwb-models.js');
  const group = new THREE.Group();
  const result = await mountCausewayBayModels(group, {
    buildings: fallback,
    manifestUrl: './manifest.json',
    fetchImpl: async () => ({ ok: true, status: 200, json: async () => manifest })
  });
  return { group, result };
}

test('default manifest is directly under hk-3d and a missing file keeps every fallback', { skip }, async () => {
  const THREE = await import('three/webgpu');
  const { mountCausewayBayModels } = await import('../js/hk/cwb-models.js');
  const group = new THREE.Group();
  let requestedUrl = '';
  const result = await mountCausewayBayModels(group, {
    buildings: fallback,
    fetchImpl: async (url) => {
      requestedUrl = url;
      return { ok: false, status: 404 };
    }
  });
  assert.equal(requestedUrl, './hk-3d/manifest.json');
  assert.equal(result.reason, 'manifest-unavailable');
  assert.equal(result.loaded, 0);
  assert.equal(result.hiddenBuildingIds.size, 0);
  assert.equal(group.children.length, 0);
});

test('invalid glTF reports the failure and cannot remove fallback geometry', { skip }, async () => {
  const previous = globalThis.ProgressEvent;
  globalThis.ProgressEvent ??= class ProgressEvent {
    constructor(type, init) { this.type = type; Object.assign(this, init); }
  };
  try {
    const { group, result } = await mountWith(manifestWith('data:model/gltf+json;base64,bm90LWpzb24='));
    assert.equal(result.reason, 'all-models-failed');
    assert.equal(result.loaded, 0);
    assert.equal(result.failed, 1);
    assert.equal(result.hiddenBuildingIds.size, 0);
    assert.equal(group.children.length, 0);
  } finally {
    if (previous === undefined) delete globalThis.ProgressEvent;
    else globalThis.ProgressEvent = previous;
  }
});

test('real GLTFLoader success converts coordinates and hides only the overlapping fallback', { skip }, async () => {
  const previous = globalThis.ProgressEvent;
  globalThis.ProgressEvent ??= class ProgressEvent {
    constructor(type, init) { this.type = type; Object.assign(this, init); }
  };
  try {
    const { group, result } = await mountWith(manifestWith(syntheticGltfUrl()));
    assert.equal(result.loaded, 1, 'one manifest entry must never be selected twice');
    assert.equal(result.loadedBuildings, 1);
    assert.equal(result.failed, 0);
    assert.equal(result.meshes, 1);
    assert.deepEqual([...result.hiddenBuildingIds], ['b1']);
    assert.deepEqual([...result.hiddenBuildings], fallback);
    assert.equal(result.colliders.length, 0, 'matched official buildings reuse the retained authoritative fallback collision');
    const mesh = group.children[0]?.children[0];
    assert.ok(mesh?.isMesh);
    assert.ok(mesh.geometry.boundingBox.min.x > 2660 && mesh.geometry.boundingBox.max.x < 2690);
    assert.ok(mesh.geometry.boundingBox.min.z > 190 && mesh.geometry.boundingBox.max.z < 220);
    assert.ok(Math.abs(mesh.geometry.boundingBox.min.y - 0.15) < 1e-5);
    assert.equal(mesh.material.metalness, 0, 'unmeasured glTF metallic fill must not darken the facade');
    const { causewayBayBuildingColliders } = await import('../js/hk/cwb-buildings.js');
    assert.equal(causewayBayBuildingColliders(fallback).length, 1, 'visual replacement does not remove gameplay collision');
  } finally {
    if (previous === undefined) delete globalThis.ProgressEvent;
    else globalThis.ProgressEvent = previous;
  }
});

test('non-building official meshes never hide fallback or add building AABB collision', { skip }, async () => {
  const previous = globalThis.ProgressEvent;
  globalThis.ProgressEvent ??= class ProgressEvent {
    constructor(type, init) { this.type = type; Object.assign(this, init); }
  };
  try {
    const { group, result } = await mountWith(manifestWith(syntheticGltfUrl(), 'TERRAIN(TB)'));
    assert.equal(result.loaded, 1);
    assert.equal(result.loadedBuildings, 0);
    assert.equal(result.failed, 0);
    assert.equal(result.hiddenBuildings.size, 0);
    assert.equal(result.hiddenBuildingIds.size, 0);
    assert.equal(result.colliders.length, 0);
    assert.equal(group.children[0]?.children[0]?.userData.hkCategory, 'TERRAIN(TB)');
  } finally {
    if (previous === undefined) delete globalThis.ProgressEvent;
    else globalThis.ProgressEvent = previous;
  }
});
