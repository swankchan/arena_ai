import assert from 'node:assert/strict';
import test from 'node:test';
import * as HK from '../js/hk/config.js';
import { HK_ROAD_PACK } from '../js/hk/full-road-geodata.js';
import { buildRoadMarkings } from '../js/hk/markings.js';

function runtimePoints(link) {
  const road = HK.ROADS[link];
  return road.pts;
}

test('full road pack preserves the complete at-grade graph and its provenance', () => {
  assert.equal(HK_ROAD_PACK.kind, 'at-grade-road-graph');
  assert.equal(HK_ROAD_PACK.nodes.length / 2, 16084);
  assert.equal(HK_ROAD_PACK.links.length, 16383);
  assert.equal(HK_ROAD_PACK.names.length, 2298);
  assert.match(HK_ROAD_PACK.source.roads, /Lands Department/);
  assert.match(HK_ROAD_PACK.source.roads, /OpenStreetMap/);
  assert.match(HK_ROAD_PACK.source.note, /omits tunnels, bridges and ramps/);
  assert.equal(HK.ROADS.length, HK_ROAD_PACK.links.length);
  assert.equal(HK.FULL_ROAD_STATS.nodes, 16084);

  let length = 0;
  for (const road of HK.ROADS) {
    assert.ok(road.len > 0 && Number.isFinite(road.len), road.id);
    assert.ok(road.w >= 3.2 && road.w <= 22, road.id);
    assert.ok(road.pts.every((p) => Number.isFinite(p.x) && Number.isFinite(p.z)), road.id);
    length += road.len;
  }
  assert.ok(length / 1000 > 1660 && length / 1000 < 1663, `${length / 1000} km`);
});

test('one-way graph links, including reverse links, have valid travel-facing geometry', () => {
  let reverse = 0;
  HK_ROAD_PACK.links.forEach((link, index) => {
    const road = runtimePoints(index);
    const expectedStart = link[5] < 0 ? link[1] : link[0];
    const expectedEnd = link[5] < 0 ? link[0] : link[1];
    assert.ok(Math.hypot(road[0].x - HK_ROAD_PACK.nodes[expectedStart * 2], road[0].z - HK_ROAD_PACK.nodes[expectedStart * 2 + 1]) < 1e-8);
    const last = road[road.length - 1];
    assert.ok(Math.hypot(last.x - HK_ROAD_PACK.nodes[expectedEnd * 2], last.z - HK_ROAD_PACK.nodes[expectedEnd * 2 + 1]) < 1e-8);
    if (link[5] < 0) reverse++;
  });
  assert.ok(reverse > 0, 'the source contains reverse-direction links');
  for (const road of HK.ROADS) {
    const shifted = HK.offsetPolyline(road.pts, 1.7);
    assert.ok(shifted.every((p) => Math.hypot(p.dx, p.dz) > 0.99), `${road.id} has a degenerate tangent`);
  }
});

test('full network markings use graph junctions and stay inside the geometry budget', () => {
  const markings = buildRoadMarkings(HK.ROADS);
  assert.ok(markings.quads > 300000, `only ${markings.quads} quads`);
  assert.ok(markings.quads < 500000, `quad budget exceeded: ${markings.quads}`);
  assert.equal(markings.triangles, markings.quads * 2);
  assert.ok(markings.positions.every(Number.isFinite));
  assert.equal(markings.positions.length / 3, markings.quads * 4);
  assert.equal(markings.indices.length, markings.quads * 6);
});

test('interim seed buildings and landmark boxes do not stand in full carriageways', () => {
  assert.equal(HK.BUILDING_STATS.fullRoadSeedConflicts, 778);
  for (const building of HK.BUILDINGS) {
    assert.ok(HK.fullRoadClearance(building) >= 2.2, `seed building at ${building.x},${building.z}`);
  }
  for (const landmark of HK.LANDMARKS) {
    assert.ok(HK.fullRoadClearance(landmark) >= 0, `${landmark.id} overlaps a carriageway`);
  }
});

test('the old loop-based AI is explicitly local until graph routing replaces it', () => {
  assert.equal(HK.TRAFFIC_ROADS.length, 148);
  assert.ok(HK.ROADS.every((road) => road.traffic === false));
  const lanes = HK.buildLanes();
  assert.equal(lanes.length, 289);
  assert.ok(lanes.every((lane) => HK.TRAFFIC_ROADS.includes(lane.road)));
  assert.ok(HK.ROADS.every((road) => !lanes.some((lane) => lane.road === road)));
});

test('full-road spawn and teleports remain on named graph roads', () => {
  assert.equal(HK.SPAWN.road, 'Connaught Road Central');
  for (const point of [HK.SPAWN, ...HK.TELEPORTS]) {
    const nearest = HK.nearestRoad(point.x, point.z, 60);
    assert.ok(nearest, `${point.road} has no graph road`);
    assert.ok(nearest.dist < 12, `${point.road}: ${nearest.dist} m away`);
    assert.equal(nearest.road.source, 'landsd-osm-graph');
  }
});
