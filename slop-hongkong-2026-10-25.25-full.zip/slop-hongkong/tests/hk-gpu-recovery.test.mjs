import assert from 'node:assert/strict';
import test from 'node:test';
import { readFileSync } from 'node:fs';
import { webglFallbackUrl, isUnexpectedDeviceLoss } from '../js/hk/gpu-recovery.js';

test('WebGPU reset recovery preserves application options and forces WebGL2', () => {
  const result = new URL(webglFallbackUrl('http://127.0.0.1:8082/?world=hk&cwbModels=0&debug=1&webgl=0#drive'));
  assert.equal(result.searchParams.get('world'), 'hk');
  assert.equal(result.searchParams.get('cwbModels'), '0');
  assert.equal(result.searchParams.get('debug'), '1');
  assert.equal(result.searchParams.get('webgl'), '1');
  assert.equal(result.hash, '#drive');
});

test('only unexpected device loss triggers recovery', () => {
  assert.equal(isUnexpectedDeviceLoss({ reason: 'unknown' }), true);
  assert.equal(isUnexpectedDeviceLoss(undefined), true);
  assert.equal(isUnexpectedDeviceLoss({ reason: 'destroyed' }), false);
});

test('device-loss recovery stops fake rendering and cannot reload in a loop', () => {
  const main = readFileSync(new URL('../js/hk/main.js', import.meta.url), 'utf8');
  assert.match(main, /if \(forceWebGL \|\| gpuRecovering \|\| !isUnexpectedDeviceLoss\(info\)\) return/);
  assert.match(main, /renderer\.setAnimationLoop\(null\)/);
  assert.match(main, /window\.location\.replace\(target\)/);
  assert.match(main, /gpuRecovering = true/);
  const html = readFileSync(new URL('../index.html', import.meta.url), 'utf8');
  assert.match(html, /'js\/hk\/gpu-recovery\.js'/, 'the static recovery import must be preloaded');
});
