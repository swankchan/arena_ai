import * as THREE from 'three/webgpu';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { hk80ToWorld, APPLICATION_FRAME } from './hk80.js';
import { parseCwbModelCap, selectCwbModels, matchCwbBuildingModels } from './cwb-model-plan.js';

// Optional LandsD Individualised photogrammetry for the CWB pilot. The offline
// real-footprint city is always the fallback; a missing/failed model never
// removes its procedural visual or gameplay collider.

const position = new THREE.Vector3();
const normal = new THREE.Vector3();
const normalMatrix = new THREE.Matrix3();

function bakeMesh(mesh, options) {
  const geometry = mesh.geometry.clone();
  const positions = geometry.getAttribute('position');
  if (!positions) return null;
  mesh.updateWorldMatrix(true, false);
  const matrix = mesh.matrixWorld;
  normalMatrix.getNormalMatrix(matrix);
  const baked = new Float32Array(positions.count * 3);
  for (let i = 0; i < positions.count; i++) {
    position.fromBufferAttribute(positions, i).applyMatrix4(matrix);
    const world = hk80ToWorld(position.x, -position.z, position.y, options);
    baked[i * 3] = world.x;
    baked[i * 3 + 1] = world.y;
    baked[i * 3 + 2] = world.z;
  }
  geometry.setAttribute('position', new THREE.BufferAttribute(baked, 3));
  const normals = geometry.getAttribute('normal');
  if (normals) {
    const bakedNormals = new Float32Array(normals.count * 3);
    for (let i = 0; i < normals.count; i++) {
      normal.fromBufferAttribute(normals, i).applyMatrix3(normalMatrix).normalize();
      bakedNormals[i * 3] = normal.x;
      bakedNormals[i * 3 + 1] = normal.y;
      bakedNormals[i * 3 + 2] = normal.z;
    }
    geometry.setAttribute('normal', new THREE.BufferAttribute(bakedNormals, 3));
  } else {
    geometry.computeVertexNormals();
  }
  geometry.computeBoundingBox();
  geometry.computeBoundingSphere();
  return geometry;
}

function prepareMaterials(object) {
  const materials = Array.isArray(object.material) ? object.material : [object.material];
  for (const material of materials) {
    if (!material) continue;
    // FME commonly writes a constant metallicFactor without a measured map.
    // Treating a façade photograph as half metal makes it muddy and dark.
    if (!material.metalnessMap && 'metalness' in material) material.metalness = 0;
    for (const key of ['map', 'emissiveMap', 'normalMap', 'roughnessMap', 'aoMap']) {
      const texture = material[key];
      if (!texture) continue;
      texture.anisotropy = 4;
      texture.generateMipmaps = true;
      if ('minFilter' in texture) texture.minFilter = THREE.LinearMipmapLinearFilter;
      texture.needsUpdate = true;
    }
    material.needsUpdate = true;
  }
}

function addGltfMeshes(group, gltf, entry, options) {
  gltf.scene.updateMatrixWorld(true);
  let count = 0;
  gltf.scene.traverse((object) => {
    if (!object.isMesh) return;
    const geometry = bakeMesh(object, options);
    if (!geometry) return;
    prepareMaterials(object);
    const mesh = new THREE.Mesh(geometry, object.material);
    mesh.name = 'CausewayBayIndividualModel';
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    mesh.userData.hkSheet = entry.sheet;
    mesh.userData.hkFile = entry.file;
    mesh.userData.hkSource = 'Lands Department Individualised model';
    group.add(mesh);
    count++;
  });
  if (!count) throw new Error('no mesh in glTF');
  return count;
}

async function mapLimit(items, limit, worker) {
  let next = 0;
  const runners = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (next < items.length) {
      const index = next++;
      await worker(items[index], index);
    }
  });
  await Promise.all(runners);
}

function emptyResult(reason = '') {
  return { loaded: 0, failed: 0, meshes: 0, reason, hiddenBuildingIds: new Set(), colliders: [], entries: [] };
}

export async function mountCausewayBayModels(group, {
  buildings,
  manifestUrl = './hk-3d/cwb/manifest.json',
  fetchImpl = globalThis.fetch,
  search = typeof location === 'undefined' ? '' : location.search,
  onProgress = async () => {}
} = {}) {
  const cap = parseCwbModelCap(search);
  if (!cap) return emptyResult('disabled');
  if (typeof location === 'undefined' && fetchImpl === globalThis.fetch) return emptyResult('not-browser');
  if (typeof fetchImpl !== 'function') return emptyResult('fetch-unavailable');

  let manifest;
  try {
    const response = await fetchImpl(manifestUrl);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    manifest = await response.json();
  } catch (error) {
    console.info(`[cwb] Individualised models unavailable; real-footprint fallback stays (${error.message})`);
    return emptyResult('manifest-unavailable');
  }

  const selected = selectCwbModels(manifest, cap);
  if (!selected.length) return emptyResult('no-intersecting-models');
  const groupModels = new THREE.Group();
  groupModels.name = 'CausewayBayIndividualModels';
  group.add(groupModels);
  const loader = new GLTFLoader();
  const entries = [];
  let failed = 0;
  let meshes = 0;
  let completed = 0;
  const options = {
    frame: manifest.frame || APPLICATION_FRAME,
    groundHKPD: manifest.groundHKPD ?? 4,
    groundY: manifest.groundY ?? 0.15
  };

  await mapLimit(selected, 3, async (entry) => {
    try {
      const url = new URL(entry.file, new URL(manifestUrl, typeof location === 'undefined' ? 'http://local/' : location.href)).href;
      const gltf = await loader.loadAsync(url);
      meshes += addGltfMeshes(groupModels, gltf, entry, options);
      entries.push(entry);
    } catch (error) {
      failed++;
      console.warn(`[cwb] model skipped ${entry.file}: ${error.message || error}`);
    } finally {
      completed++;
      await onProgress(`銅鑼灣官方照片模型 ${completed}/${selected.length}…`);
    }
  });

  if (!entries.length) {
    group.remove(groupModels);
    return { ...emptyResult('all-models-failed'), failed };
  }
  const { hiddenBuildingIds, matchedFiles } = matchCwbBuildingModels(entries, buildings);
  const colliders = entries.filter((entry) => !matchedFiles.has(entry.file)).map((entry) => ({
    minX: entry.minX,
    maxX: entry.maxX,
    minZ: entry.minZ,
    maxZ: entry.maxZ,
    minY: entry.minY,
    maxY: entry.maxY,
    kind: 'building',
    source: 'landsd-individual-model',
    id: entry.file
  }));
  console.info(`[cwb] Individualised models ${entries.length}; fallback parts hidden ${hiddenBuildingIds.size}; failed ${failed}`);
  return { loaded: entries.length, failed, meshes, reason: '', hiddenBuildingIds, colliders, entries };
}
