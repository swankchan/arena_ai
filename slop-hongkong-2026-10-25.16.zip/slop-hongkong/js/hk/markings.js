// js/hk/markings.js
// 香港道路標線：一次過寫進單一 typed array，唔會為每一段虛線開一個 BufferGeometry。
//
// （原本寫法對每條虛線段 new 一個 BufferGeometry，香港走廊總共一萬三千個，再 mergeGeometries，
//   主執行緒要卡幾秒至十幾秒，瀏覽器會出 "Page Unresponsive"。改成純陣列之後：一個 geometry、一次上傳。）
//
// 這裡刻意唔 import three.js，所以可以直接在 Node 裡單元測試。

const push = (arr, ...v) => {
  for (const x of v) arr.push(x);
};

/**
 * 沿折線在「行車方向左側」offset 米處畫一條寬 width 的標線（含虛線）。
 * @returns {{positions: Float32Array, indices: Uint32Array, quads: number, triangles: number}}
 */
export function buildRoadMarkings(roads, {
  laneWidth = 3.4,
  y = 0.17,
  lineWidth = 0.14,
  centreWidth = 0.13,
  dash = 4,
  gap = 6,
  edgeInset = 0.5,
  maxQuads = 200000
} = {}) {
  const positions = [];
  const indices = [];
  let quads = 0;

  function quad(ax, az, bx, bz, w) {
    if (quads >= maxQuads) throw new Error('road markings: quad budget exceeded (bad geometry?)');
    const dx = bx - ax;
    const dz = bz - az;
    const len = Math.hypot(dx, dz);
    if (!(len > 0.05) || !Number.isFinite(len)) return;
    const nx = (dz / len) * (w / 2);
    const nz = (-dx / len) * (w / 2);
    const base = positions.length / 3;
    push(positions, ax + nx, y, az + nz, ax - nx, y, az - nz, bx - nx, y, bz - nz, bx + nx, y, bz + nz);
    push(indices, base, base + 1, base + 2, base, base + 2, base + 3);
    quads++;
  }

  /**
   * 在偏移 off 的位置畫線。dash > 0 時按相位切段（相位跨段累加，彎位不會重置）。
   * 用索引運算而非 while，避免任何浮點邊界造成的無限迴圈。
   */
  function line(pts, off, w, { dashed = false, phase = 0 } = {}) {
    const period = dash + gap;
    let run = phase;
    for (let i = 0; i + 1 < pts.length; i++) {
      const a = pts[i];
      const b = pts[i + 1];
      const dx = b.x - a.x;
      const dz = b.z - a.z;
      const segLen = Math.hypot(dx, dz);
      if (!(segLen > 0.05)) continue;
      const ux = dx / segLen;
      const uz = dz / segLen;
      const lx = uz; // 行車方向左側的法線（靠左行駛，見 config.js laneLateral）
      const lz = -ux;
      const ox = lx * off;
      const oz = lz * off;
      if (!dashed) {
        quad(a.x + ox, a.z + oz, b.x + ox, b.z + oz, w);
        continue;
      }
      // 這一段內，第 k 條虛線的起點：run + t ≡ 0 (mod period)
      const first = Math.ceil(run / period) * period - run;
      const steps = Math.floor((segLen - first) / period) + 1;
      for (let k = 0; k < steps; k++) {
        const t0 = first + k * period;
        if (t0 < 0 || t0 >= segLen) continue;
        const t1 = Math.min(segLen, t0 + dash);
        if (t1 - t0 < 0.2) continue;
        quad(
          a.x + ux * t0 + ox, a.z + uz * t0 + oz,
          a.x + ux * t1 + ox, a.z + uz * t1 + oz,
          w
        );
      }
      run += segLen;
    }
  }

  const countFor = (road, dir) => {
    if (road.oneway) return Math.max(1, road.lanesPerWay || 1);
    return Math.max(1, Math.round((dir === 1 ? road.lanesForward : road.lanesBackward) ?? road.lanesPerWay ?? 1));
  };
  const widthFor = (road, dir) => {
    const count = countFor(road, dir);
    return Math.min(laneWidth, (road.oneway ? road.w : road.w / 2) / count);
  };

  // 真實資料在路口切成短段。標線在 T／十字路口前留空，唔再直接畫過路口；
  // 同名前後段仍當作連續道路。呢啲係由幾何推導的標線，唔係 Traffic Aids 測量成果。
  const pointToRoad = (p, road) => {
    let best = Infinity;
    const pts = road.pts;
    for (let i = 0; i + 1 < pts.length; i++) {
      const a = pts[i];
      const b = pts[i + 1];
      const dx = b.x - a.x;
      const dz = b.z - a.z;
      const l2 = dx * dx + dz * dz || 1e-9;
      const t = Math.max(0, Math.min(1, ((p.x - a.x) * dx + (p.z - a.z) * dz) / l2));
      best = Math.min(best, Math.hypot(p.x - (a.x + dx * t), p.z - (a.z + dz * t)));
    }
    return best;
  };
  const junctionAt = (road, p) => road.source === 'landsd-osm' && roads.some((other) => (
    other !== road && other.en !== road.en && pointToRoad(p, other) < 4.2
  ));

  for (const road of roads) {
    let pts = dedupe(road.pts);
    if (pts.length < 2) continue;
    if (road.source === 'landsd-osm') {
      const trimStart = junctionAt(road, pts[0]) ? 3.5 : 0;
      const trimEnd = junctionAt(road, pts[pts.length - 1]) ? 3.5 : 0;
      pts = trimPolyline(pts, trimStart, trimEnd);
      if (pts.length < 2) continue;
    }
    const half = road.w / 2;
    // 路邊線（實線）
    line(pts, half - edgeInset, lineWidth);
    line(pts, -(half - edgeInset), lineWidth);
    if (road.oneway) {
      const count = countFor(road, 1);
      const width = widthFor(road, 1);
      for (let i = 1; i < count; i++) line(pts, -width * count / 2 + i * width, lineWidth, { dashed: true });
    } else {
      // 雙白線；詳細線型仍待 Traffic Aids 資料，唔假稱每個路口都係咁。
      line(pts, 0.22, centreWidth);
      line(pts, -0.22, centreWidth);
      for (const dir of [1, -1]) {
        const count = countFor(road, dir);
        const width = widthFor(road, dir);
        for (let i = 1; i < count; i++) line(pts, dir * i * width, lineWidth, { dashed: true });
      }
    }
  }

  return {
    positions: Float32Array.from(positions),
    indices: Uint32Array.from(indices),
    quads,
    triangles: quads * 2
  };
}

/** 折線頭尾各截去指定長度，並在切口插回準確點。 */
export function trimPolyline(input, start = 0, end = 0) {
  const pts = dedupe(input);
  if (pts.length < 2 || (start <= 0 && end <= 0)) return pts;
  let total = 0;
  for (let i = 1; i < pts.length; i++) total += Math.hypot(pts[i].x - pts[i - 1].x, pts[i].z - pts[i - 1].z);
  if (total - start - end < 1) return [];
  const pointAt = (distance) => {
    let left = Math.max(0, Math.min(total, distance));
    for (let i = 1; i < pts.length; i++) {
      const a = pts[i - 1];
      const b = pts[i];
      const len = Math.hypot(b.x - a.x, b.z - a.z);
      if (left <= len || i === pts.length - 1) {
        const t = len ? Math.max(0, Math.min(1, left / len)) : 0;
        return { x: a.x + (b.x - a.x) * t, z: a.z + (b.z - a.z) * t };
      }
      left -= len;
    }
    return pts[pts.length - 1];
  };
  const first = pointAt(start);
  const last = pointAt(total - end);
  const out = [first];
  let run = 0;
  for (let i = 1; i < pts.length - 1; i++) {
    run += Math.hypot(pts[i].x - pts[i - 1].x, pts[i].z - pts[i - 1].z);
    if (run > start && run < total - end) out.push(pts[i]);
  }
  out.push(last);
  return dedupe(out);
}

/** 去掉連續重複（或距離 < 1 cm）的點，避免零長度線段產生 NaN 法線。 */
export function dedupe(pts) {
  const out = [];
  for (const p of pts) {
    const last = out[out.length - 1];
    if (!last || Math.hypot(p.x - last.x, p.z - last.z) > 0.01) out.push(p);
  }
  return out;
}
