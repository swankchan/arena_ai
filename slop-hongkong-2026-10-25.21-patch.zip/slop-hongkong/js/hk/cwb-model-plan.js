// Pure planning helpers for optional LandsD Individualised models. No three.js
// import: data selection and fallback matching can be tested on a bare checkout.

// A complete local sheet is the default. A positive ?cwbModels=N remains a
// debugging/performance cap; ?cwbModels=0 still disables the optional layer.
const DEFAULT_CAP = Number.POSITIVE_INFINITY;
const MAX_CAP = 240;
const ZONES = [
  { key: 'north', test: (entry) => centre(entry).z < 80, anchor: { x: 2820, z: 150 } },
  { key: 'core', test: (entry) => centre(entry).z >= 80 && centre(entry).z < 330, anchor: { x: 2670, z: 220 } },
  { key: 'south', test: (entry) => centre(entry).z >= 330, anchor: { x: 2520, z: 410 } }
];

function centre(entry) {
  return { x: (entry.minX + entry.maxX) / 2, z: (entry.minZ + entry.maxZ) / 2 };
}

function intersects(entry, bounds, margin = 12) {
  return entry.maxX >= bounds.minX - margin && entry.minX <= bounds.maxX + margin
    && entry.maxZ >= bounds.minZ - margin && entry.minZ <= bounds.maxZ + margin;
}

function validEntry(entry) {
  return entry?.file && ['minX', 'maxX', 'minZ', 'maxZ'].every((key) => Number.isFinite(entry[key]));
}

export function isBuildingModel(entry) {
  // The original twenty-entry manifest predates category metadata and contained
  // only BUILDING models, so an absent category deliberately means BUILDING.
  return String(entry?.category || 'BUILDING').toUpperCase() === 'BUILDING';
}

export function parseCwbModelCap(search = '') {
  const value = new URLSearchParams(search).get('cwbModels');
  if (value == null || value === '' || value.toLowerCase() === 'all') return DEFAULT_CAP;
  const number = Number(value);
  if (!Number.isFinite(number)) return DEFAULT_CAP;
  return Math.max(0, Math.min(MAX_CAP, Math.floor(number)));
}

/**
 * Select every valid model by default, including small buildings and categories
 * outside BUILDING. A finite cap keeps the old north/core/south balancing
 * behaviour instead of spending the whole allowance at one junction.
 */
export function selectCwbModels(manifest, cap = DEFAULT_CAP) {
  if (!(cap > 0)) return [];
  const all = [];
  const seen = new Set();
  for (const entry of manifest?.buildings || []) {
    if (!validEntry(entry) || seen.has(entry.file)) continue;
    seen.add(entry.file);
    all.push(entry);
  }
  if (!Number.isFinite(cap) || cap >= all.length) return all;

  const bounds = manifest?.bounds;
  const candidates = bounds ? all.filter((entry) => intersects(entry, bounds)) : all;
  const zones = ZONES.map((zone) => candidates.filter((entry) => zone.test(entry)).sort((a, b) => {
    const ca = centre(a);
    const cb = centre(b);
    const da = Math.hypot(ca.x - zone.anchor.x, ca.z - zone.anchor.z);
    const db = Math.hypot(cb.x - zone.anchor.x, cb.z - zone.anchor.z);
    return da - db || String(a.file).localeCompare(String(b.file));
  }));
  const selected = [];
  const selectedFiles = new Set();
  for (let i = 0; selected.length < cap; i++) {
    let added = false;
    for (const zone of zones) {
      if (i < zone.length && selected.length < cap && !selectedFiles.has(zone[i].file)) {
        selected.push(zone[i]);
        selectedFiles.add(zone[i].file);
        added = true;
      }
    }
    if (!added) break;
  }
  return selected;
}

function buildingBounds(building) {
  if (Array.isArray(building?.ring)) {
    const box = { minX: Infinity, maxX: -Infinity, minZ: Infinity, maxZ: -Infinity };
    for (let i = 0; i + 1 < building.ring.length; i += 2) {
      box.minX = Math.min(box.minX, building.ring[i]);
      box.maxX = Math.max(box.maxX, building.ring[i]);
      box.minZ = Math.min(box.minZ, building.ring[i + 1]);
      box.maxZ = Math.max(box.maxZ, building.ring[i + 1]);
    }
    return Object.values(box).every(Number.isFinite) ? box : null;
  }
  if ([building?.x, building?.z, building?.w, building?.d].every(Number.isFinite)) {
    const c = Math.abs(Math.cos(building.rot || 0));
    const s = Math.abs(Math.sin(building.rot || 0));
    const hx = (building.w * c + building.d * s) / 2;
    const hz = (building.w * s + building.d * c) / 2;
    return { minX: building.x - hx, maxX: building.x + hx, minZ: building.z - hz, maxZ: building.z + hz };
  }
  return null;
}

function overlapRatio(a, b) {
  const width = Math.max(0, Math.min(a.maxX, b.maxX) - Math.max(a.minX, b.minX));
  const depth = Math.max(0, Math.min(a.maxZ, b.maxZ) - Math.max(a.minZ, b.minZ));
  const intersection = width * depth;
  const areaA = Math.max(0.01, (a.maxX - a.minX) * (a.maxZ - a.minZ));
  const areaB = Math.max(0.01, (b.maxX - b.minX) * (b.maxZ - b.minZ));
  return intersection / Math.min(areaA, areaB);
}

/**
 * Only successfully loaded BUILDING models can replace procedural buildings.
 * Terrain, infrastructure, vegetation, water and generic photomesh stay visual
 * overlays: their large bounds must never hide a building or become an AABB
 * "building" wall. The object set supports legacy seed buildings without IDs;
 * hiddenBuildingIds remains for callers/tests whose fallback records have IDs.
 */
export function matchCwbBuildingModels(entries, buildings) {
  const hiddenBuildingIds = new Set();
  const hiddenBuildings = new Set();
  const matchedFiles = new Set();
  const bounds = (buildings || []).map((building) => ({ building, box: buildingBounds(building) }))
    .filter((item) => item.box);
  for (const entry of entries) {
    if (!isBuildingModel(entry)) continue;
    for (const { building, box } of bounds) {
      if (overlapRatio(entry, box) < 0.12) continue;
      hiddenBuildings.add(building);
      if (building.id != null) hiddenBuildingIds.add(building.id);
      matchedFiles.add(entry.file);
    }
  }
  return { hiddenBuildingIds, hiddenBuildings, matchedFiles };
}
